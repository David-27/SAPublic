
import os
from datalib.punt_data_provider import PuntDataProvider
import pandas as pd


DATA_PATH = 'C:/Users/user/Studienarbeit/data/'

if not os.path.exists(f'{DATA_PATH}indices'):
    os.mkdir(f'{DATA_PATH}indices')

data_provider = PuntDataProvider(prefix=DATA_PATH)

# Return: (2286, 13)
# Fair Catch: (1640, 13)
# Muffed: (154, 13)
# Downed: (829, 13)

def index_result_class(args):
    result, name = args
    print(f'Creating {name}.csv...')
    result_df = (data_provider.data_plays.loc[data_provider.data_plays['specialTeamsResult'] == result])[['gameId', 'playId']]
    result_df[events] = None

    i = 0
    for row_index, row in result_df.iterrows():
        print(f'{result} :: {i} / {result_df.shape[0]}    ', end='\r')
        i += 1
        play_id = row['playId']
        game_id = row['gameId']

        for event in events:
            try:
                e = (data_provider.data_tracking.loc[(data_provider.data_tracking['gameId'] == game_id) & (data_provider.data_tracking['playId'] == play_id) & (data_provider.data_tracking['event'] == event)])['frameId'].unique()[0]
                result_df.loc[result_df.index == row_index, event] = e
            except IndexError:
                pass

    result_df.to_csv(f'{DATA_PATH}/indices/{name}.csv')
    return result_df


if __name__ == '__main__':
    events = ['ball_snap', 'punt', 'punt_land', 'punt_downed', 'fair_catch', 'punt_received', 'first_contact', 'tackle', 'punt_muffed']
    results = ['Downed', 'Return', 'Muffed', 'Fair Catch']
    names = ['downed_df', 'return_df', 'muffed_df', 'fair_catch_df']
    args =  zip(results, names)
    
    result_dfs = []
    for arg in args:
        result_df = index_result_class(arg)
        result_dfs.append(result_df)
    
    print('\nCreating sections...')


    if not os.path.exists(f'{DATA_PATH}sections'):
        os.mkdir(f'{DATA_PATH}sections')

    total = pd.concat(result_dfs).sample(frac=1)

    sec_1 = total[:(total.shape[0] // 4)]
    sec_2 = total[(total.shape[0] // 4):(total.shape[0] // 2)]
    sec_3 = total[(total.shape[0] // 2):( 3 * total.shape[0] // 4)]
    sec_4 = total[( 3 * total.shape[0] // 4):]

    print('Writing sections...')
    sec_1.to_csv(f'{DATA_PATH}sections/section_1.csv')
    sec_2.to_csv(f'{DATA_PATH}sections/section_2.csv')
    sec_3.to_csv(f'{DATA_PATH}sections/section_3.csv')
    sec_4.to_csv(f'{DATA_PATH}sections/section_4.csv')
    print('Done.')