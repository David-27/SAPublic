import numpy as np
import pandas as pd
import tensorflow.keras as tk
import tensorflow.keras.backend as K

DATA_PATH = 'C:/Users/user/Studienarbeit/data/'
MODEL_PATH = r'C:\Users\user\Studienarbeit\code\4431738220543333815_final.h5'
TARGET_VAR = 0

def pct_below(y, y_bar):
    return np.count_nonzero(y > y_bar) / len(y)

def pct_above(y, y_bar):
    return np.count_nonzero(y < y_bar) / len(y)
    
def mean_squared_error(y, y_bar):
    diff = y - y_bar
    diff_sq = diff **2
    mse = diff_sq.sum() / len(y)
    return mse

def mean_abs_error(y, y_bar):
    diff = abs(y - y_bar)
    mse = diff.sum() / len(y)
    return mse

def mean_error(y, y_bar):
    diff = y - y_bar
    mse = diff.sum() / len(y)
    return mse

def error_above_below(y, y_bar, error='MAE'):
    if len(y) == 0:
        return 0, 0
    above_vals_y = y[y_bar > y]
    above_vals_y_bar = y_bar[y_bar > y]
    below_vals_y = y[y_bar < y]
    below_vals_y_bar = y_bar[y_bar < y]
    if error == 'MAE':
        return mean_abs_error(above_vals_y, above_vals_y_bar), mean_abs_error(below_vals_y, below_vals_y_bar)
    elif error == 'MSE':
        return mean_squared_error(above_vals_y, above_vals_y_bar), mean_squared_error(below_vals_y, below_vals_y_bar)
    elif error == 'ME':
        return mean_error(above_vals_y, above_vals_y_bar), mean_error(below_vals_y, below_vals_y_bar)
    else:
        return mean_abs_error(above_vals_y, above_vals_y_bar), mean_abs_error(below_vals_y, below_vals_y_bar)

def extract_data(target_id):
    min_data_amount = 400
    indexes_eval = []
    indexes_tr = []
    
    i = 0
    for id in collector_X_eval_ids:
        if int(id) == int(target_id):
            indexes_eval.append(i)
        i += 1
    
    if len(indexes_eval) < (min_data_amount / 2):    
        remaining_data = min_data_amount
    else:
        remaining_data = len(indexes_eval) * 2
    
    i = 0
    for id in collector_X_tr_ids:
        if int(id) == int(target_id) and len(indexes_tr) < remaining_data:
            indexes_tr.append(i)
        i += 1
        
    X_collector = []
    y_collector = []
    for index_e in indexes_eval:
        X_collector.append(collector_X_eval_only[index_e, :, :, :])
        y_collector.append(collector_y_eval_only[index_e, :])
    for index_t in indexes_tr:
        X_collector.append(collector_X_tr[index_t, :, :, :])
        y_collector.append(collector_y_tr[index_t, :])
    return np.array(X_collector), np.array(y_collector)


collector_X_eval_ids = np.load(f'{DATA_PATH}F/collector_id_eval_only.npy')
eval_count_dict = {}
RELEV_IDS = []
for id in collector_X_eval_ids:
    if not(str(id) in eval_count_dict.keys()):
        RELEV_IDS.append(int(id))
        eval_count_dict[str(id)] = 0
    eval_count_dict[str(id)] += 1
eval_count_dict

collector_X_tr_ids = np.load(f'{DATA_PATH}F/collector_id_tr.npy')
count_dict = {}
for id in collector_X_tr_ids:
    if not(str(id) in count_dict.keys()):
        count_dict[str(id)] = 0
    count_dict[str(id)] += 1
count_dict

collector_X_tr = np.load(f'{DATA_PATH}F/collector_X_tr.npy')
collector_y_tr = np.load(f'{DATA_PATH}F/collector_y_tr.npy')
collector_X_eval_only = np.load(f'{DATA_PATH}F/collector_X_eval_only.npy')
collector_y_eval_only = np.load(f'{DATA_PATH}F/collector_y_eval_only.npy')

model = tk.models.load_model(MODEL_PATH)

collection_dict = {}
for id in RELEV_IDS:
    X, y = extract_data(id)
    y_actual = y[:, TARGET_VAR]
    y_pred = model.predict(X)
    y_pred = y_pred.reshape((y_pred.shape[0], ))
    
    below_score = pct_below(y_actual, y_pred)
    above_score = pct_above(y_actual, y_pred)
    mae_above, mae_below = error_above_below(y_actual, y_pred)
    
    collection_dict[id] = (above_score, below_score, mae_above, mae_below)

score_dict = {}

for k in collection_dict.keys():
    above_score, below_score, mae_above, mae_below = collection_dict[k]
    score = - above_score * mae_above + below_score * mae_below
    score_dict[k] = score

A_df = pd.DataFrame({'A' : score_dict.values()}, index=score_dict.keys())
A_df.to_csv(f'{DATA_PATH}A_df.csv')

# print(A_df)
