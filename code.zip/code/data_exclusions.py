import random
import pandas as pd
import numpy as np

DATA_PATH = 'C:/Users/user/Studienarbeit/data/'

CUTOFF = 30
df = pd.read_csv(f'{DATA_PATH}punts_plays_enhanced.csv')
df_np = df.loc[df['penaltyCodes'].isna()]
dfid1 = pd.read_csv(f'{DATA_PATH}ids.csv')

def parse_array(string):
    if string == '[]':
        return []
    arr_list = string.split(',')
    if len(arr_list) == 1:
        return [int(float((arr_list[0])[1:-1]))]
    arr_list[0] = int(float((arr_list[0])[1:]))
    arr_list[-1] = (arr_list[-1])[:-1]
    for i in range(1, len(arr_list)):
        arr_list[i] = int(float((arr_list[i])[1:]))
    return arr_list

def calculate_result_percentage(dic, target_key):
    sum = 0
    target = 0
    for key in dic.keys():
        sum += dic[key]
        if key == target_key:
            target = dic[key]
    return target / sum

def calculate_play_total(dic):
    sum = 0
    for key in dic.keys():
        sum += dic[key]
    return sum


data_dict2 = {}
for row_id, row in dfid1.iterrows():
    game_id = row['gameId']
    play_id = row['playId']
    selection = df_np.loc[(df_np['gameId'] == game_id) & (df_np['playId'] == play_id)]
    if selection.empty:
        continue
    result = selection['specialTeamsResult'].item()
    for key in parse_array(row['gunners']):
        if not(key in data_dict2.keys()):
            data_dict2[key] = []
        data_set = (game_id, play_id, result)
        data_dict2[key].append(data_set)

processed_dd2 = {}
for key in data_dict2.keys():
    data_list = data_dict2[key]
    interm_dict = {
        'Touchback' : 0,
        'Fair Catch' : 0,
        'Return' : 0,
        'Downed' : 0,
        'Out of Bounds' : 0,
        'Muffed' : 0,
        'Blocked Punt' : 0
    }
    for data_point in data_list:
        game_id, play_id, result = data_point
        interm_dict[result] += 1
    processed_dd2[key] = interm_dict

filtered_dd2 = {}
for player_key in processed_dd2.keys():
    player_entry = processed_dd2[player_key]
    if calculate_play_total(player_entry) > CUTOFF:
        filtered_dd2[player_key] = player_entry

processed_filtered_dd21 = {}
for player_key in filtered_dd2.keys():
    player_entry = filtered_dd2[player_key]
    interm_dict = {}
    for target_key in ['Fair Catch', 'Return', 'Downed', 'Muffed']:
        result_percentage = calculate_result_percentage(player_entry, target_key)
        interm_dict[target_key] = result_percentage
    processed_filtered_dd21[player_key] = interm_dict
pfdd21_df = pd.DataFrame(processed_filtered_dd21)
relevant_players = np.array(pfdd21_df.T.index)

data_dict = {}
for row_id, row in dfid1.iterrows():
    game_id = row['gameId']
    play_id = row['playId']
    selection = df_np.loc[(df_np['gameId'] == game_id) & (df_np['playId'] == play_id)]
    if selection.empty:
        continue
    result = selection['playResult'].item()
    for key in parse_array(row['gunners']):
        if not(key in data_dict.keys()):
            data_dict[key] = []
        data_set = (game_id, play_id, result)
        data_dict[key].append(data_set)

exclusions = set()
for key in data_dict.keys():
    if key in relevant_players:
        player_data = data_dict[key]
        selection = random.sample(player_data, 15)
        for a, b, c in selection:
            exclusions.add((key, a, b, c))

pd.DataFrame(exclusions, columns=['nflId', 'gameId', 'playId', 'playResult']).to_csv(f'{DATA_PATH}exclusions.csv')
