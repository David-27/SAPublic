import pandas as pd
import colorama
from colorama import Fore, Style

colorama.init()

DATA_PATH = 'C:/Users/user/Studienarbeit/data/'

print('Loading files...')
try:
    # NFL play data, plays from 2018 have a 2018* gameId, playId unique per game
    data_plays = pd.read_csv(f'{DATA_PATH}plays.csv')
    # tracking data 2018
    data_2018 = pd.read_csv(f'{DATA_PATH}tracking2018.csv')
    # tracking data 2019
    data_2019 = pd.read_csv(f'{DATA_PATH}tracking2019.csv')
    # tracking data 2020
    data_2020 = pd.read_csv(f'{DATA_PATH}tracking2020.csv')
    # NFL player data
    data_players = pd.read_csv(f'{DATA_PATH}players.csv')
    # NFL game data
    data_games = pd.read_csv(f'{DATA_PATH}games.csv')
    # PFF Scouting data
    data_sc = pd.read_csv(f'{DATA_PATH}PFFScoutingData.csv')
except FileNotFoundError:
    print(Fore.RED + 'No such file or directory.' + Style.RESET_ALL)
print('Loaded files.')

print('Reducing tracking data...')
punts = data_plays.loc[data_plays['specialTeamsPlayType'] == 'Punt']
punts_keys = punts[['gameId', 'playId']]

punts_keys_2018 = punts_keys.loc[punts_keys['gameId'] < 2019000000]
punts_keys_2019 = punts_keys.loc[(punts_keys['gameId'] < 2020000000) & (punts_keys['gameId'] > 2019000000)]
punts_keys_2020 = punts_keys.loc[punts_keys['gameId'] > 2020000000]

dfs_2018 = []
print('Reducing tracking data 2018...')
for game_id, play_id in zip(punts_keys_2018['gameId'], punts_keys_2018['playId']):
    play_tracking_df = data_2018.loc[(data_2018['gameId'] == game_id) & (data_2018['playId'] == play_id)]
    dfs_2018.append(play_tracking_df)
print('Reducing tracking data 2019...')
dfs_2019 = []
for game_id, play_id in zip(punts_keys_2019['gameId'], punts_keys_2019['playId']):
    play_tracking_df = data_2019.loc[(data_2019['gameId'] == game_id) & (data_2019['playId'] == play_id)]
    dfs_2019.append(play_tracking_df)
print('Reducing tracking data 2020...')
dfs_2020 = []
for game_id, play_id in zip(punts_keys_2020['gameId'], punts_keys_2020['playId']):
    play_tracking_df = data_2020.loc[(data_2020['gameId'] == game_id) & (data_2020['playId'] == play_id)]
    dfs_2020.append(play_tracking_df)

all_tracking_2018 = pd.concat(dfs_2018, axis=0)
all_tracking_2019 = pd.concat(dfs_2019, axis=0)
all_tracking_2020 = pd.concat(dfs_2020, axis=0)

all_tracking = pd.concat([all_tracking_2018, all_tracking_2019,all_tracking_2020], axis=0, ignore_index=True)

print('Reducing player data...')
ids = all_tracking['nflId'].unique()
relevant_players = []
for id in ids:
    player = data_players.loc[data_players['nflId'] == id]
    relevant_players.append(player)

relev_players_df = pd.concat(relevant_players, axis=0, ignore_index=True)   

print('Reducing scouting data...')
dfs_pff = []
for game_id, play_id in zip(punts_keys['gameId'], punts_keys['playId']):
    play_pff_df = data_sc.loc[(data_sc['gameId'] == game_id) & (data_sc['playId'] == play_id)]
    dfs_pff.append(play_pff_df)

sc_df = pd.concat(dfs_pff, axis=0, ignore_index=True)

print('Saving punt data files...')
punts.to_csv(f'{DATA_PATH}/punts_plays.csv')
all_tracking.to_csv(f'{DATA_PATH}/punts_tracking.csv')
relev_players_df.to_csv(f'{DATA_PATH}/punts_players.csv')
sc_df.to_csv(f'{DATA_PATH}/punts_PFFScoutingData.csv')
print('Saved punt data files.')