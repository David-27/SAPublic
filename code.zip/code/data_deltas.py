import itertools
import multiprocessing
from datalib.punt_data_provider import PuntDataProvider
import numpy as np
import pandas as pd
from concurrent.futures import ProcessPoolExecutor

from util import CustomBar


def calculate_deltas(data_provider, play_data):
    df = data_provider.data_tracking.loc[(data_provider.data_tracking['gameId'] == play_data.game_id) & (data_provider.data_tracking['playId'] == play_data.play_id)]
    ids = df['nflId'].unique()
    max_frame_id = df['frameId'].unique().max()
    
    df.reset_index(inplace=True)
    df = df.rename(columns = {'index':'global_index'})
    dfs = []
    
    for id in ids:
        for frame_id in range(1, max_frame_id + 1):
        
            if frame_id == max_frame_id:
                delta_x = np.nan
                delta_y = np.nan
                if np.isnan(id):
                    global_index = (df.loc[np.isnan(df['nflId']) & (df['frameId'] == frame_id)])['global_index'].item()
                else:
                    global_index = (df.loc[(df['nflId'] == id) & (df['frameId'] == frame_id)])['global_index'].item()
                
            else:
                if np.isnan(id):
                    x_0 = (df.loc[np.isnan(df['nflId']) & (df['frameId'] == frame_id)])['x'].item()
                    x_1 = (df.loc[np.isnan(df['nflId']) & (df['frameId'] == frame_id + 1)])['x'].item()
                    
                    y_0 = (df.loc[np.isnan(df['nflId']) & (df['frameId'] == frame_id)])['y'].item()
                    y_1 = (df.loc[np.isnan(df['nflId']) & (df['frameId'] == frame_id + 1)])['y'].item()
                    
                    global_index = (df.loc[np.isnan(df['nflId']) & (df['frameId'] == frame_id)])['global_index'].item()
                    
                else:
                    x_0 = (df.loc[(df['nflId'] == id) & (df['frameId'] == frame_id)])['x'].item()
                    x_1 = (df.loc[(df['nflId'] == id) & (df['frameId'] == frame_id + 1)])['x'].item()
                    
                    y_0 = (df.loc[(df['nflId'] == id) & (df['frameId'] == frame_id)])['y'].item()
                    y_1 = (df.loc[(df['nflId'] == id) & (df['frameId'] == frame_id + 1)])['y'].item()
                    
                    global_index = (df.loc[(df['nflId'] == id) & (df['frameId'] == frame_id)])['global_index'].item()
                    
                delta_y = y_1 - y_0
                delta_x = x_1 - x_0
            
            result_df = pd.DataFrame(np.array([[global_index, id, frame_id, delta_x, delta_y]]), columns=['global_index', 'nflId', 'frameId', 'deltaX', 'deltaY'])
            result_df = result_df.set_index('global_index')
            dfs.append(result_df)
            
    concat_dfs = pd.concat(dfs)
    df = df.join(concat_dfs, on=['global_index'], rsuffix='_r')
    
    df = df.set_index('global_index')
    df.index.name = None
    
    df.drop(['nflId_r', 'frameId_r'], axis=1, inplace=True)
    
    return df

def split_list(n, k):
    l = range(n)
    return [l[i * (n // k) + min(i, n % k):(i+1) * (n // k) + min(i+1, n % k)] for i in range(k)]

def calc_deltas_partial(args):
    id, indices, path = args
    data_provider = PuntDataProvider(prefix=path, load_plays_as_enhanced=True, load_tracking_as_adjusted=True, load_tracking_data_as_normalized=False, load_tracking_as_adjusted_expanded=False)
    dfs = []

    if id == 0:
        bar =  CustomBar('Calculating deltas', max=5991)

    for i in indices:
        play = data_provider.get_play_by_index(i)
        df = calculate_deltas(data_provider, play)
        dfs.append(df)
        if id == 0:
            bar.next(multiprocessing.cpu_count() // 2)

    return dfs 


if __name__ == '__main__':
    DATA_PATH = 'C:/Users/user/Studienarbeit/data/'
    path = DATA_PATH

    list_chunks = split_list(5991, multiprocessing.cpu_count() // 2)
    paths = [path for _ in range(len(list_chunks))]
    args = [(i, list_chunk, path) for (i, list_chunk, path) in zip(range(len(list_chunks)), list_chunks, paths)]

    with ProcessPoolExecutor(multiprocessing.cpu_count() // 2) as ex:
        results = ex.map(calc_deltas_partial, args)

    dfs = list(itertools.chain.from_iterable(results))
    df_cc = pd.concat(dfs)

    df_cc.to_csv(f'{DATA_PATH}punts_tracking_adjusted_expanded.csv')
    print('\n\ndone')


