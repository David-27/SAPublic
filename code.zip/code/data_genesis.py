import datetime
import pandas as pd
from datalib.punt_data_provider import PuntDataProvider

DATA_PATH = 'C:/Users/user/Studienarbeit/data/'
data_provider = PuntDataProvider(prefix=DATA_PATH, load_tracking_data_as_normalized=False)

def get_jersey_numbers_gunners(game_id, play_id):
    sc_data = data_provider.get_scouting_data_by_id(game_id, play_id)
    gunner_str = sc_data.gunners
    str_list = gunner_str.split('; ')
    
    game = data_provider.get_game_by_id(game_id)
    teamPuntingAbbr = game.get_home_team() if (data_provider.find_team_in_possession(game_id, play_id) == 'home') else game.get_visitor_team()
    
    jersey_numbers = []
    for s in str_list:
        number = s[len(teamPuntingAbbr)+1:]
        jersey_numbers.append(number)
    
    return jersey_numbers

def find_returner_nfl_id_and_jersey_number(game_id, play_id):
    players = data_provider.get_super_players_from_play(game_id, play_id)
    xs = []
    
    for player in players:
        x, y = player.get_starting_position()
        xs.append(x)
    
    index = xs.index(max(xs))
    jersey_number = players[index].tracking_data['jerseyNumber'].unique()[0]
    nfl_id = players[index].tracking_data['nflId'].unique()[0]
    
    return nfl_id, jersey_number

def generate_id_list(game_id, play_id, track=True, error_track=True):
    # home_team_jerseys, away_team_jerseys = get_jersey_numbers_by_team(play.game_id, play.play_id)

    try:
        gunner_jerseys = get_jersey_numbers_gunners(game_id, play_id)
        gunner_jerseys_ints = [int(i) for i in gunner_jerseys]
    except:
        if track and error_track:
            print(f'{str(datetime.datetime.now())}   Caught gunner error in game {str(game_id)} on play {str(play_id)}.')

    try:
        team_in_possession = data_provider.find_team_in_possession(game_id, play_id)
        players = data_provider.get_super_players_from_play(game_id, play_id)

        offense_ids = []
        defense_ids = []
        gunner_ids = []

        for player in players:
            jersey_number = player.get_jersey_number()
            player_id = player.nfl_id
            team = player.get_team()

            if team_in_possession == team:
                offense_ids.append(player_id)
                if int(jersey_number) in gunner_jerseys_ints:
                    gunner_ids.append(player_id)
            else:
                defense_ids.append(player_id)

        return offense_ids, defense_ids, gunner_ids

    except KeyboardInterrupt:
        raise KeyboardInterrupt
    except:
        if track and error_track:
            print(f'{str(datetime.datetime.now())}   Caught other error in game {str(game_id)} on play {str(play_id)}.')
            


def generate_data(id_df, track=True, error_track=False):
    
    data_dict = {
        'gameId' : [],
        'playId' : [],
        'offense' : [],
        'defense' : [],
        'gunners' : [],
    }
    counter = 0
    
    for _, row in id_df.iterrows():
        if track:
            counter += 1
            print(str(datetime.datetime.now()) + '   ' + str(counter) + '/' + str(id_df.shape[0]), end='\r')
        
        game_id = int(row['gameId'])
        play_id = int(row['playId'])

        try:
            offense, defense, gunners = generate_id_list(game_id, play_id, track=track, error_track=error_track)

            data_dict['gameId'].append(game_id)
            data_dict['playId'].append(play_id)
            data_dict['offense'].append(offense)
            data_dict['defense'].append(defense)
            data_dict['gunners'].append(gunners)
        except KeyboardInterrupt:
            raise KeyboardInterrupt
        except:
            if track and error_track:
                print(f'{str(datetime.datetime.now())}   Caught other error in game {str(game_id)} on play {str(play_id)}.')

    return pd.DataFrame(data_dict)
        
        
df = pd.read_csv(f'{DATA_PATH}punts_plays_enhanced.csv')
idf = df

result_df = generate_data(id_df=idf, track=True, error_track=False)
filestr = DATA_PATH + f'ids.csv'

result_df.to_csv(filestr)