import numpy as np
from tensorflow.keras.layers import Input, Conv2D, Activation, Lambda, MaxPooling2D, MaxPooling1D, BatchNormalization, Conv1D, AvgPool1D, AvgPool2D, Dense, Add
from tensorflow.keras import Model
import tensorflow.keras.backend as K
import tensorflow as tf
import numpy as np
import datetime
import matplotlib.pyplot as plt
import traceback
import argparse

parser = argparse.ArgumentParser(description='GM Training script 0.7.1')
group = parser.add_argument_group('architecture')
group.add_argument('-conv2d', '--convolution_2d', help='Number of filters in the 2D convolution layer.  If any, at least one must be specified.', type=int, nargs='+', default=[180, 224, 180])
group.add_argument('-conv1d', '--convolution_1d', help='Number of filters in the 1D convolution layer.  If any, at least one must be specified.', type=int, nargs='+', default=[224, 134, 134])
group.add_argument('-l2d', '--lambda_2d', help='Value of the lambda parameters after the 2D max/avg pooling layers. If any, exactly two must be specified.', type=float, nargs=2, default=[0.3, 0.7])
group.add_argument('-l1d', '--lambda_1d', help='Value of the lambda parameters after the 1D max/avg pooling layers. If any, exactly two must be specified.', type=float, nargs=2, default=[0.3, 0.7])
group.add_argument('-d', '--dense', help='Neurons in the dense layers. If any, at least one must be specified.', type=str, nargs='+', default=[134, 360, 256])

group = parser.add_argument_group('training')
group.add_argument('-lr', '--learning_rate', help='Learning rate of the model. If any, at least one must be specified. Number of arguments should match EPOCHS.', type=float, nargs='+', default=[0.001, 0.0001])
group.add_argument('-e', '--epochs', help='Number of epochs to train the model for. If any, at least one must be specified. Number of arguments should match LEARNING_RATE.', type=int, nargs='+', default=[15, 6]) 
group.add_argument('-bs', '--batch_size', help='Batch size during training.', type=int, default=32)
group.add_argument('-t', '--target', help='Target variable of the network: \'x\' or \'y\'', type=str, default='x', choices=['x', 'y'])
group.add_argument('-l', '--loss', help='Loss function used to train the model. Possible values: [\'mae\', \'mse\', \'msle\']', type=str, default='mse')
group.add_argument('-m', '--metrics', help='Metrics used to evaluate the model performance. Possible values: [\'mae\', \'mse\', \'msle\']. If any, at least one must be specified.', type=str, nargs='+', default=['mse', 'mae', 'msle'])
group.add_argument('-vs', '--validation_split', help='Validation split used on the training data.', type=float, default=0.2)

group = parser.add_argument_group('files')
group.add_argument('-data', '--data_directory', help='Path of the directory containing the data files used for training.', type=str, default=r'C:/Users/user/Studienarbeit/data/F/')
group.add_argument('-plot', '--plot_directory', help='Path of the directory to store the plots.', type=str, default=r'C:/Users/user/Studienarbeit/plots/')
group.add_argument('-log', '--log_file', help='Path of the *.txt file to store the logs.', type=str, default=r'C:/Users/user/Studienarbeit/logs/log_F.txt')
group.add_argument('-hash', '--hash_file', help='Path of the *.txt file to store the hashes and the configs.', type=str, default=r'C:/Users/user/Studienarbeit/hash_F.txt')
group.add_argument('-model', '--model_file', help='Path of the *.h5 file that stores the model to load.', type=str, default=r'undefined')
group.add_argument('-stype', '--save_type', help='Whether to save the model as h5 or in the Saved Model-format.', type=str, default=r'h5', choices=['h5', 'SM'])

args = parser.parse_args()
hash_code = str(hash(str(args)))


with open(args.hash_file, 'a') as f:
    line = f'{str(datetime.datetime.now())}   :   {hash_code}   ==> {str(args)}\n'
    f.write(line)

configuration = {
    'optimizer' : tf.keras.optimizers.Adam(1e-3),
    'training_data_X' : [r'collector_X_tr.npy'],
    'training_data_y' : [r'collector_y_tr.npy'],
    'test_data_X' : [r'collector_X_eval_only.npy'],
    'test_data_y' : [r'collector_y_eval_only.npy'],
    'test_data_ids' : [r'collector_id_eval_only.npy'],
}

short_dict = {
    'mean_squared_error' : 'mse', 
    'mean_squared_logarithmic_error' : 'msle', 
    'mean_absolute_error' : 'mae'
}

long_dict = {
    'mse' : 'mean_squared_error', 
    'msle' : 'mean_squared_logarithmic_error', 
    'mae' : 'mean_absolute_error'
}

target_dict = {
    'x' : 0,
    'y' : 1
}


def log(message, to_file=True):
    output = f'{str(datetime.datetime.now())}   :   ' + str(message)
    print(output)
    if to_file:
        log_file.write(output + '\n')


def get_model(verbose=2):
    if verbose > 1:
        log('Constructing model...', to_file=False)

    input_dense_players = Input(shape=(14,10,11), name = "Input")

    x = input_dense_players

    for n in args.convolution_2d:
        x = Conv2D(n, kernel_size=(1,1), strides=(1,1), activation=None)(x)
        x = Activation('relu')(x)

    lambda_2d_max = args.lambda_2d[0]
    lambda_2d_avg = args.lambda_2d[1]
    xmax = MaxPooling2D(pool_size=(1,10))(x)
    xmax = Lambda(lambda x1 : x1 * lambda_2d_max)(xmax)
    xavg = AvgPool2D(pool_size=(1,10))(x)
    xavg = Lambda(lambda x1 : x1 * lambda_2d_avg)(xavg)

    x = Add()([xmax, xavg])
    x = Lambda(lambda y : K.squeeze(y,2))(x)
    x = BatchNormalization()(x)

    for n in args.convolution_1d:
        x = Conv1D(n, kernel_size=1, strides=1, activation=None)(x)
        x = Activation('relu')(x)
        x = BatchNormalization()(x)

    lambda_1d_max = args.lambda_1d[0]
    lambda_1d_avg = args.lambda_1d[1]
    xmax = MaxPooling1D(pool_size=10)(x)
    xmax = Lambda(lambda x1 : x1 * lambda_1d_max)(xmax)
    xavg = AvgPool1D(pool_size=10)(x)
    xavg = Lambda(lambda x1 : x1 * lambda_1d_avg)(xavg)
    x = Add()([xmax, xavg])
    x = Lambda(lambda y : K.squeeze(y,1))(x)

    for n in args.dense:
        x = Dense(n)(x)
        x = Activation('relu')(x)
        x = BatchNormalization()(x)

    out_reg = Dense(1, activation='linear', name = "Output")(x)
    local_model = Model(inputs = [input_dense_players], outputs = [out_reg])
    if verbose > 2:
        log(local_model.summary(), to_file=False)
    return local_model

def create_metric_plot(data, data_keys, title, xlabel, ylabel, show=False, file=None, legend_loc='upper left'):
    plt.clf()
    for key in data_keys:
        plt.plot(data[key], label=key)
    plt.title(title)
    plt.ylabel(ylabel)
    plt.xlabel(xlabel)
    plt.legend(loc=legend_loc)
    if show:
        plt.show()
    if not(file is None):
        plt.savefig(plot_path + file)

def create_scatter_plot(actual, predicted, colors, title, xlabel, ylabel, show=False, file=None, legend_loc='lower right'):
    plt.clf()
    plt.scatter(actual, predicted, label='actual vs predicted', s=3, c=colors)
    plt.plot([np.array(actual).min(), np.array(actual).max()], [np.array(actual).min(), np.array(actual).max()], c='red', label='optimum')
    plt.title(title)
    plt.ylabel(ylabel)
    plt.xlabel(xlabel)
    plt.legend(loc=legend_loc)
    if show:
        plt.show()
    if not(file is None):
        plt.savefig(plot_path + file)

###############################################################################################

log_file = open(args.log_file, 'a')
log(f'Hash path: {str(args.hash_file)}', to_file=False)
log(hash_code)
log(str(args))

path = str(args.data_directory)
log(f'Data path: {path}', to_file=False)

plot_path = str(args.plot_directory)
log(f'Plot path: {plot_path}', to_file=False)

loss = args.loss
loss_long = long_dict[loss]
metrics = list(map(lambda s: long_dict[s], args.metrics))
epochs = args.epochs
learning_rates = args.learning_rate
target_var_char = args.target
target_var_int = target_dict[args.target]
validation_split = args.validation_split

if args.model_file != 'undefined':
    # skip training if a model path is defined
    model = tf.keras.models.load_model(args.model_file)
else:
    log_file = open(args.log_file, 'a')
    log(f'Hash path: {str(args.hash_file)}', to_file=False)
    log(hash_code)
    log(str(args))

    path = str(args.data_directory)
    log(f'Data path: {path}', to_file=False)

    plot_path = str(args.plot_directory)
    log(f'Plot path: {plot_path}', to_file=False)

    # load training data
    tr_X = []
    tr_y = []

    for file_X, file_y in zip(configuration['training_data_X'], configuration['training_data_y']):
        with open(path + file_X, 'rb') as f:
            tr_X.append(np.load(f))
        with open(path + file_y, 'rb') as f:
            tr_y.append(np.load(f))

    X_tr = np.vstack(tr_X)
    y_tr = np.vstack(tr_y)
    y_tr = y_tr[:, target_var_int]

    log('Data check:', to_file=False)
    log('Check for NaN values in training data by use of isnan() :', to_file=False)
    log(f'X (any | sum) :   {str(np.isnan(X_tr).any())}  |  {str(np.isnan(X_tr).sum())}/{str(X_tr.shape[0])}', to_file=False)
    log(f'y (any | sum) :   {str(np.isnan(y_tr).any())}  |  {str(np.isnan(y_tr).sum())}/{str(y_tr.shape[0])}', to_file=False)

    try:
        log(f'Getting model for loss configuration: {loss_long}', to_file=False)
        model = get_model()

        model.compile(
            optimizer=configuration['optimizer'],
            loss=loss_long,
            metrics=metrics,
        )
        log('Compiled model.', to_file=False)

        try:
            histories = []
            first_lr = True

            for e, learning_rate in zip(epochs, learning_rates):
                log(f'Training for {str(e)} epochs with learning rate {learning_rate}.', to_file=False)

                if not(first_lr):
                    K.set_value(model.optimizer.learning_rate, learning_rate)
                first_lr = False

                history = model.fit(X_tr, y_tr, epochs=e, validation_split=validation_split)
                histories.append(history.history)

        except Exception as e:
            log('Training has been interrupted.', to_file=False)
            print(e)
            traceback.print_exc()


    except Exception as e:
        log('Process has been stopped.', to_file=False)
        print(e)
        traceback.print_exc()

    finally:
        for hist in histories:
            print(hist)

        suffix = '_final'
        if args.save_type == 'h5':
            suffix = '_final.h5'
        tf.keras.models.save_model(model, f'{str(hash_code)}{suffix}')
        model.save_weights(f'{hash_code}_final_weights.h5')
        log('Saved model. Initiating test sequence.', to_file=False)

# load test data
test_X = []
test_y = []
test_ids = []

for file_X, file_y, file_ids in zip(configuration['test_data_X'], configuration['test_data_y'], configuration['test_data_ids']):
    with open(path + file_X, 'rb') as f:
        test_X.append(np.load(f))
    with open(path + file_y, 'rb') as f:
        test_y.append(np.load(f))
    with open(path + file_ids, 'rb') as f:
        test_ids.append(np.load(f))

X_test = np.vstack(test_X)
y_test = np.vstack(test_y)
y_test = y_test[:, target_var_int]
ids_test = np.vstack(test_ids)

log('Data check:', to_file=False)
log('Check for NaN values in test data by use of isnan() :', to_file=False)
log(f'X (any | sum) :   {str(np.isnan(X_test).any())}  |  {str(np.isnan(X_test).sum())}/{str(X_test.shape[0])}', to_file=False)
log(f'y (any | sum) :   {str(np.isnan(y_test).any())}  |  {str(np.isnan(y_test).sum())}/{str(y_test.shape[0])}', to_file=False)

scores = model.evaluate(X_test, y_test)
# for metric, score in zip(metrics, scores):
#     log(f'{str(metric)}  :  {str(score)}')
#     data = []
#     val_data = []
#     for i in range(0, len(epochs)):
#         data.append((histories[i])[str(metric)])
#         val_data.append((histories[i])['val_' + str(metric)])
#     data = np.hstack(data)
#     val_data = np.hstack(val_data)
#     title = f'{short_dict[str(metric)]} - network trained for {target_var_char} with loss: {loss}'
#     file = f'{hash_code}_{short_dict[str(metric)]}.png'
#     create_metric_plot(data={
#         str(metric): data,
#         'val_' + str(metric): val_data
#     }, data_keys=[str(metric), 'val_' + str(metric)], title=title, xlabel='epochs', ylabel='metric', file=file)
# 
# log_file.close()

actual = y_test[:100000]
predictions = model.predict(X_test[:100000, :, :, :])
ids = ids_test[:, :100000]

print()
print(f'actual: {actual.shape}')
print(f'predictions: {predictions.shape}')
print(f'ids: {ids.shape}')

title = f'{str(loss)} for {target_var_char} - evaluated on 10000 random unseen samples'
file = f'{hash_code}_{target_var_char}_scatter.png'
xlabel = f'Actual delta {target_var_char} in a 0.1s intervall'
ylabel = f'Predicted delta {target_var_char} in a 0.1s intervall'

create_scatter_plot(actual=actual, predicted=predictions, colors=ids, title=title, xlabel=xlabel, ylabel=ylabel, file=file)
