from dateutil import parser

def calculate_age_in_years(time_of_play, birth_day):
    play = parser.parse(time_of_play)
    bday = parser.parse(birth_day)
    delta_years = play.year - bday.year
    delta_months = play.month - bday.month
    if delta_months < 0:
        return delta_years - 1
    else:
        delta_days = play.day - bday.day
        if delta_days < 0:
            return delta_years - 1
    return delta_years

def calculate_height_in_inches(height_str):
    # example string: '6-0' meaning 6' 0''
    if '-' in height_str:
        str_arr = height_str.split('-')
        height_component_feet = int(str_arr[0])
        height_component_inches = int(str_arr[1])
        return height_component_feet * 12.0 + height_component_inches * 1.0
    else:
        return int(height_str) * 1.0