from colorama import Fore, Back, Style
from progress.bar import Bar

def printc(text, foreground=Fore.WHITE, background=Back.BLACK, style=Style.NORMAL):
    print(foreground + background + style + text + Style.RESET_ALL)

class CustomBar(Bar):
    space_str = ' ' * 10
    suffix = '%(index)d/%(max)d - ETA: %(eta_minutes)d min' + space_str
    
    @property
    def eta_minutes(self):
        return self.eta // 60
