from datalib.player_display_data import PlayerDisplayData
import math

class SuperPlayerPlayData:
    # contains all data of a player as represented by ~/data/players.csv
    # contains all data of a play as represented by ~/data/plays.csv
    # additionally collects all the tracking data of one play of one game

    def __init__(self, nfl_id, game_id, play_id):
        self.nfl_id = nfl_id
        self.game_id = game_id
        self.play_id = play_id
    
    def add_player_data(self, player_data):
        self.nfl_id = player_data.nfl_id
        self.player = player_data
    
    def add_tracking_data(self, pd_data_frame):
        self.tracking_data = pd_data_frame
    
    def is_frame_available(self, frame_id):
        return frame_id in self.tracking_data['frameId'].values

    def get_team(self):
        return self.tracking_data['team'].unique()[0]

    def get_starting_position(self):
        return self.tracking_data['x'].values[0], self.tracking_data['y'].values[0]
    
    def get_position_and_speed(self, frame_id, verbose: bool = True):
        data = self.tracking_data.loc[self.tracking_data['frameId'] == frame_id]
        
        # angle = data['dir'].item() * 2 * math.pi / 360 - (math.pi / 2)
        # s_x = math.cos(angle) * data['s'].item()
        # s_y = math.sin(angle) * data['s'].item()

        if data['outlier'].item() and verbose:
            print('Outlier detected')
            raise Exception()

        return data['x'].item(), data['y'].item(), data['sX'].item(), data['sY'].item()

    def get_deltas(self, frame_id, verbose: bool = True):
        data = self.tracking_data.loc[self.tracking_data['frameId'] == frame_id]

        if data['outlier'].item() and verbose:
            print('Outlier detected')
            raise Exception()

        return data['deltaX'].item(), data['deltaY'].item()
    
    
    def get_display_data(self, frame_id):
        data = self.tracking_data.loc[self.tracking_data['frameId'] == frame_id]
        return PlayerDisplayData(data['x'].item(), data['y'].item(), data['dir'].item(), data['s'].item(), data['a'].item(), self.player.weight)

    def get_jersey_number(self):
        return self.tracking_data['jerseyNumber'].unique()[0]




