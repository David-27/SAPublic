
from datalib.punt_data_provider import PuntDataProvider
import numpy as np

def find_hang_period(values, length):
    val_len = values.shape[0]
    errors = []
    for i in range(0, val_len - length):
        approximate_slope = (values[i + length - 1] - values[i]) / length
        error = 0
        for k in range(i, i + length - 1):
            error += abs(values[k] - (approximate_slope * k + values[i]))
        error /= length
        errors.append(error)

    # x = [i for i in range(0, len(errors))]
    # y = errors
    # ax = plt.plot(x, y, color = 'r')
    # plt.show()
                          
    min_error = max(errors)
    index_list = [i for i, j in enumerate(errors) if j == min_error]
    return index_list[0]

DATA_PATH = 'C:\\Users\\user\\Studienarbeit\\data\\'
data_provider = PuntDataProvider(False, False, False, False, prefix=DATA_PATH)

generated_data = []

invalid_data = [
    (310, 2018092302, 3437),
    (635, 2018100711, 253),
    (880, 2018102111, 3651),
    (1756, 2018121501, 449),
    (2227, 2019090807, 1293),
    (2944, 2019102006, 2301),
    (4512, 2020100401, 211)
]

relev_plays = data_provider.data_plays.loc[(data_provider.data_plays['specialTeamsResult'] == 'Return') | 
                             (data_provider.data_plays['specialTeamsResult'] == 'Fair Catch') |
                             (data_provider.data_plays['specialTeamsResult'] == 'Muffed') |
                             (data_provider.data_plays['specialTeamsResult'] == 'Downed')]
relev_ids = []


for id, play in relev_plays.iterrows():
    relev_ids.append((id, play['gameId'], play['playId']))

for id, game_id, play_id in relev_ids:
    if (id, game_id, play_id) in invalid_data:
        continue
    print(f'{(id, game_id, play_id)}    ', end='\r')

    play_data = data_provider.get_play_by_id(game_id, play_id)
    sc_data = data_provider.get_scouting_data_by_id(game_id, play_id)
    super_football_data = data_provider.get_super_football_data(game_id, play_id)
    x = super_football_data.tracking_data['x'].values[:]
    
    kick_length = play_data.kick_length
    
    
    hang_time = int(sc_data.hang_time * 10)
    op_time = int(sc_data.operation_time * 10)
    snap_time = int(sc_data.snap_time * 10)
    
    i = find_hang_period(x, int(kick_length))
    o = i - op_time - snap_time
    
    punt_index = i
    snap_index = o + snap_time
    received_index = punt_index + hang_time
    
    generated_data.append((id, game_id, play_id, snap_index, punt_index, received_index))

print('\nDONE.')

plays_df = data_provider.data_plays.copy(deep=True)
plays_df[['snap', 'punt', 'reception']] = np.nan

for id, game_id, play_id, snap_index, punt_index, received_index in generated_data:
    plays_df.loc[(plays_df['gameId'] == game_id) & (plays_df['playId'] == play_id), 'snap'] = snap_index
    plays_df.loc[(plays_df['gameId'] == game_id) & (plays_df['playId'] == play_id), 'punt'] = punt_index 
    plays_df.loc[(plays_df['gameId'] == game_id) & (plays_df['playId'] == play_id), 'reception'] = received_index

plays_df.to_csv(f'{DATA_PATH}punts_plays_enhanced.csv')