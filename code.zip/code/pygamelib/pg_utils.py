import os
os.environ['PYGAME_HIDE_SUPPORT_PROMPT'] = "hide"

from football.fb_constants import END_ZONE_LENGTH, FIELD_LENGTH, FIELD_WIDTH, LINE_WIDTH, NUMBER_LINE_WIDTH, NUMBER_OFFSET_TO_LINE, NUMBER_SIZE, NUMBER_WIDTH, TEN_YARD_ZONE_LENGTH, YARD
from pygamelib.pg_constants import END_ZONE_COLOR, MARGIN_LTRB, WHITE, YARD_ZONE_DARK_GREEN, YARD_ZONE_LIGHT_GREEN
import pygame
import math
from pygamelib.pg_math import rotate_polygon

# draw football field
def draw_football_field(game_window):
        # NOTE:  x y -> .Rect(left, top, size_x, size_y)
        offset_x = MARGIN_LTRB[0]
        offset_y = MARGIN_LTRB[1]
        # draw frame
        pygame.draw.rect(game_window, WHITE, pygame.Rect(offset_x, offset_y, FIELD_LENGTH, FIELD_WIDTH))
        # draw end zones
        pygame.draw.rect(game_window, END_ZONE_COLOR, 
            pygame.Rect(pygame.Rect(offset_x + LINE_WIDTH, offset_y + LINE_WIDTH, END_ZONE_LENGTH - 2 * LINE_WIDTH, FIELD_WIDTH - 2 * LINE_WIDTH)))
        pygame.draw.rect(game_window, END_ZONE_COLOR,
            pygame.Rect(pygame.Rect(offset_x + FIELD_LENGTH - END_ZONE_LENGTH + LINE_WIDTH, offset_y + LINE_WIDTH, END_ZONE_LENGTH - 2 * LINE_WIDTH, FIELD_WIDTH - 2 * LINE_WIDTH)))

        # draw 10 10-yard zones
        additional_offset_x = END_ZONE_LENGTH
        for i in range(10):
            color = YARD_ZONE_LIGHT_GREEN if (i % 2 == 0) else YARD_ZONE_DARK_GREEN
            total_offset_x = offset_x + additional_offset_x + LINE_WIDTH
            pygame.draw.rect(game_window, color, 
                pygame.Rect(pygame.Rect(total_offset_x, offset_y + LINE_WIDTH, TEN_YARD_ZONE_LENGTH -  2 * LINE_WIDTH, FIELD_WIDTH - 2 * LINE_WIDTH)))
            pygame.draw.rect(game_window, WHITE, 
                pygame.Rect(pygame.Rect(total_offset_x + TEN_YARD_ZONE_LENGTH / 2, offset_y + LINE_WIDTH, LINE_WIDTH, FIELD_WIDTH - 2 * LINE_WIDTH)))
            additional_offset_x += 10 * YARD
        
        # draw centered star and numbering
        draw_centered_star(game_window)
        draw_numbering(game_window)

# takes up the calculation of the centering of the star
def draw_centered_star(game_window, color = WHITE, size = 20):
    center_x = MARGIN_LTRB[0] + END_ZONE_LENGTH + 50 * YARD
    center_y = MARGIN_LTRB[1] + FIELD_WIDTH / 2
    draw_star_polygon(game_window, center_x = center_x, center_y = center_y, color = color, size = size)

# star defaults to a size of 20
def draw_star_polygon(game_window, color = WHITE, center_x = 0, center_y = 0, size = 20):
    points = get_star_polygon(center_x = center_x, center_y = center_y, size = size)
    pygame.draw.polygon(game_window, color, points)

def get_star_polygon(center_x = 0, center_y = 0, size = 20):
    return [
            (center_x, center_y - size),
            (center_x + size / 4, center_y - size / 4),
            (center_x + size, center_y),
            (center_x + size / 4, center_y + size / 4),
            (center_x, center_y + size),
            (center_x - size / 4, center_y + size / 4),
            (center_x - size, center_y),
            (center_x - size / 4, center_y - size / 4),
        ]

def draw_numbering(game_window, color = WHITE, size = NUMBER_SIZE):
    # draw numbering
    # offset of top numbering = 12 YARDS from top side line
    offset_y_top_numbering = MARGIN_LTRB[1] + 12 * YARD
    # offset of bottom numbering = 12 YARDS from top side line
    offset_y_bottom_numbering = FIELD_WIDTH + MARGIN_LTRB[1] - 12 * YARD - size
    
    
    for k in range(-1, 2, 2):
        # k = -1 => draw top numbering    ==> zeros to the left,  non-zeros to the right
        # k =  1 => draw bottom numbering ==> zeros to the right, non-zeros to the left
        additional_offset_x_top_zeros = MARGIN_LTRB[0] + 10 * YARD + END_ZONE_LENGTH - NUMBER_OFFSET_TO_LINE - NUMBER_WIDTH
        additional_offset_x_bottom_zeros = MARGIN_LTRB[0] + 10 * YARD + END_ZONE_LENGTH + NUMBER_OFFSET_TO_LINE
        additional_offset_x_top_non_zeros = MARGIN_LTRB[0] + 10 * YARD + END_ZONE_LENGTH + NUMBER_OFFSET_TO_LINE
        additional_offset_x_bottom_non_zeros = MARGIN_LTRB[0] + 10 * YARD + END_ZONE_LENGTH - NUMBER_OFFSET_TO_LINE - NUMBER_WIDTH

        for i in range(1, 10, 1):
            if k < 0:
                # draw zero to the left of the line
                draw_number_polygon(game_window, 0, offset_top = offset_y_top_numbering, offset_left = additional_offset_x_top_zeros, color = color, size = size, rotation = math.pi)
                # draw number to the right of the line
                j = i if i <= 5 else 10 - i
                draw_number_polygon(game_window, j, offset_top = offset_y_top_numbering, offset_left = additional_offset_x_top_non_zeros, color = color, size = size, rotation = math.pi)
                additional_offset_x_top_zeros += 10 * YARD
                additional_offset_x_top_non_zeros += 10 * YARD
            else:
                # draw zero to the right of the line
                draw_number_polygon(game_window, 0, offset_top = offset_y_bottom_numbering, offset_left = additional_offset_x_bottom_zeros, color = color, size = size)
                # draw number to the left of the line
                j = i if i <= 5 else 10 - i
                draw_number_polygon(game_window, j, offset_top = offset_y_bottom_numbering, offset_left = additional_offset_x_bottom_non_zeros, color = color, size = size)
                additional_offset_x_bottom_zeros += 10 * YARD
                additional_offset_x_bottom_non_zeros += 10 * YARD

# numbers defualt to a height of 21 and a width of 9
def draw_number_polygon(game_window, number, color = WHITE, offset_left = 0, offset_top = 0, size = NUMBER_SIZE, rotation = 0):
    # NOTE: rotation will turn the number polygon around itself, not e. g. the center of the field
    points = get_number_polygon(number, offset_left = offset_left, offset_top = offset_top, size = size)
    if rotation != 0:
        points = rotate_polygon(points, math.pi, 
            center=[offset_left + NUMBER_WIDTH / 2, offset_top + size / 2])
    pygame.draw.lines(game_window, color, False, points, NUMBER_LINE_WIDTH)

def get_number_polygon(number, offset_left = 0, offset_top = 0, size = NUMBER_SIZE):
    if number == 0:
        width = size * 3 / 7
        points =  [
            [offset_left, offset_top],
            [offset_left + width , offset_top],
            [offset_left + width, offset_top + size],
            [offset_left, offset_top + size],
            # close the zero
            [offset_left, offset_top],
        ]
    elif number == 1:
        width = size * 3 / 7
        points = [
            [offset_left + width / 2, offset_top],
            [offset_left + width / 2, offset_top + size]
        ]
    elif number == 2:
        width = size * 3 / 7
        points = [
            [offset_left, offset_top],
            [offset_left + width , offset_top],
            [offset_left + width, offset_top + size / 2],
            [offset_left, offset_top + size / 2],
            [offset_left, offset_top + size],
            [offset_left + width, offset_top + size]
        ]
    elif number == 3:
        width = size * 3 / 7
        points = [
            [offset_left, offset_top],
            [offset_left + width , offset_top],
            [offset_left + width, offset_top + size / 2],
            [offset_left, offset_top + size / 2],
            [offset_left + width, offset_top + size / 2],
            [offset_left + width, offset_top + size],
            [offset_left, offset_top + size],
        ]
    elif number == 4:
        width = size * 3 / 7
        points = [
            [offset_left, offset_top],
            [offset_left, offset_top + size / 2],
            [offset_left + width, offset_top + size / 2],
            [offset_left + width , offset_top],
            [offset_left + width, offset_top + size] 
        ]
    elif number == 5:
        width = size * 3 / 7
        points = [
            [offset_left + width , offset_top],
            [offset_left, offset_top],
            [offset_left, offset_top + size / 2],
            [offset_left + width, offset_top + size / 2],
            [offset_left + width, offset_top + size],
            [offset_left, offset_top + size],
        ]
    return [[int(point[0]), int(point[1])] for point in points]
