from colorama import Style, Fore, init
import tensorflow as tf


def check_gpu_usage():
    print('Tensorflow version: ' + tf.version.VERSION)
    if tf.test.gpu_device_name(): 
        print(Fore.GREEN + 'Default GPU Device: {}'.format(tf.test.gpu_device_name()) + Style.RESET_ALL)
    else:
       print(Fore.RED + "Please install GPU version of TF" + Style.RESET_ALL)

init()
check_gpu_usage()