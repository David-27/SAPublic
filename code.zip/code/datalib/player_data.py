class PlayerData:
    # contains all data of a player as represented by ~/data/players.csv
    
    def __init__(self, nfl_id):
        self.nfl_id = nfl_id
    
    def init_data(self, pandas_series):
        self.height = pandas_series['height'].item()
        self.weight = pandas_series['weight'].item()
        self.birth_date = pandas_series['birthDate'].item()
        self.college_name = pandas_series['collegeName'].item()
        self.position = pandas_series['Position'].item()
        self.display_name = pandas_series['displayName'].item()
    
    # def __init__(self, nfl_id, height, weight, birth_date, college_name, position, display_name):
    #     self.nfl_id = nfl_id
    #     self.height = height
    #     self.weight = weight
    #     self.birth_date = birth_date
    #     self.college_name = college_name
    #     self.position = position
    #     self.display_name = display_name