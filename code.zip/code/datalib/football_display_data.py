class FootballDisplayData:
    # contains all the data needed to display a football at a given moment

    def __init__(self, x, y, speed, acceleration):
        self.x = x
        self.y = y
        self.speed = speed
        self.acceleration = acceleration
    
    def get_coordinates(self):
        return self.x, self.y