from pygamelib.pg_constants import MARGIN_LTRB

'''
>> Football Game constants
'''

'''
Visualization of the playing field and the coordiates

(0, 53.3)                               (120. 53.3)
            _ _ _ _ _ _ _  _ _ _ _ _ _ _
  y ^      | |           |            | |
    |      | |           |            | |
    |      | |           |            | |
    |      |_|_ _ _ _ _ _|_ _ _ _ _ __|_|
(0, 0)                                  (120, 0)
           -----------------------------> x
'''


# dimensions of the playing fields in 0.1 [yd] = 0,9144 [m]
YARD = 10
FIELD_WIDTH = int(53.3 * YARD)
FIELD_LENGTH = 120 * YARD
END_ZONE_LENGTH = 10 * YARD
TEN_YARD_ZONE_LENGTH = 10 * YARD

LINE_WIDTH = 1
NUMBER_WIDTH = 3
NUMBER_OFFSET_TOP = 12 * YARD

# football dimensions: length 11" = 0.31 [yd], width 6.5" = 0.18 [yd]
FOOTBALL_ZOOM_FACTOR = 2.3
FOOTBALL_LENGTH = 0.31 * YARD * FOOTBALL_ZOOM_FACTOR
FOOTBALL_WIDTH = 0.18 * YARD * FOOTBALL_ZOOM_FACTOR

# actual size is 2 yd, not 2.1 yd
NUMBER_SIZE = 2 * YARD + 1
NUMBER_WIDTH = NUMBER_SIZE * 3 / 7
NUMBER_LINE_WIDTH = 3
NUMBER_OFFSET_TO_LINE = YARD

# football field coordinate system starts in the bottom left corner
COORDINATE_SYSTEM_CENTER = [MARGIN_LTRB[0], MARGIN_LTRB[1] + FIELD_WIDTH]

# offset, depends on the margin,
# how do the coordinates translate to the margins
OFFSET = MARGIN_LTRB

PLAYER_POSITIONS = {"WR" : "Wide Receiver",
                   "CB" : "Cornerback",
                   "RB" : "Running Back",
                   "TE" : "Tight End",
                   "OLB" : "Outside Linebacker",
                   "QB" : "Quarterback",
                   "FS" : "Free Safety",
                   "LB" : "Linebacker",
                   "SS" : "Strong Safety",
                   "ILB" : "Inside Linebacker",
                   "DE" : "Defensive End",
                   "DB" : "Defensive Back",
                   "MLB" : "Middle Linebacker",
                   "DT" : "Defensive Tackle",
                   "FB" : "Fullback",
                   "P" : "Punter",
                   "LS" : "Long snapper",
                   "S" : "Safety",
                   "K" : "Kicker",
                   "HB" : "Running back",
                   "NT" : "Nose Tackle"}

'''
<< Game constants
'''

SPECIAL_TEAMS_RESULTS_PUNT = {
  'Blocked Punt': 39,
  'Downed': 829,
  'Fair Catch': 1640,
  'Muffed': 154,
  'Non-Special Teams Result': 74,
  'Out of Bounds': 586,
  'Return': 2286,
  'Touchback': 383
}