import os
os.environ['PYGAME_HIDE_SUPPORT_PROMPT'] = "hide"

import pygame

# margin determines the size of the frame around the football field
MARGIN_LEFT = 20
MARGIN_TOP = 20
MARGIN_RIGHT = 20
MARGIN_BOTTOM = 20
MARGIN_LTRB = (MARGIN_LEFT, MARGIN_TOP, MARGIN_RIGHT, MARGIN_BOTTOM)

# Colors (R, G, B)
BLACK = pygame.Color(0, 0, 0)
WHITE = pygame.Color(255, 255, 255)
GREEN = pygame.Color(0, 255, 0)
RED = pygame.Color(255, 0, 0)
TRANSPARENT_RED = pygame.Color(255, 0, 0, 127)
BLUE = pygame.Color(0, 0, 255)
TRANSPARENT_BLUE = pygame.Color(0, 0, 255, 127)

END_ZONE_COLOR = pygame.Color(11, 71, 135)
FOOTBALL_COLOR = pygame.Color(156, 28, 19)
YARD_ZONE_LIGHT_GREEN = pygame.Color(79, 194, 37)
YARD_ZONE_DARK_GREEN = pygame.Color(56, 156, 19)