"""
Game Visualizer to show the plays
"""

from datalib.data_provider import DataProvider
from pygamelib.pg_football import draw_football, draw_player
from pygamelib.pg_utils import draw_football_field
from pygamelib.pg_constants import BLACK, MARGIN_LTRB, TRANSPARENT_BLUE, TRANSPARENT_RED
from football.fb_constants import FIELD_LENGTH, FIELD_WIDTH
from util import printc
import pygame
import sys
from colorama import init
from colorama import Fore
import time

class Game:
    def __init__(self, game_id, play_id):
        self.game_id = game_id
        self.play_id = play_id
        self.data_provider = DataProvider(years=[2018])

        ''' >> Setup of pygame and colorama '''
        # colorama init
        init()
        # Checks for errors encountered
        # pygame.init() example output -> (x, 0)
        # second number in tuple is the number of errors
        check_errors = pygame.init()
        if check_errors[1] > 0:
            printc(f'[ERROR] Had {check_errors[1]} errors when initialising game, exiting...', foreground=Fore.RED)
            sys.exit(-1)
        else:
            printc('[GAME] Game successfully initialised', foreground=Fore.GREEN)
        # Initialise game window to the size of the field plus the surrounding margin
        pygame.display.set_caption('Play Visualizer')
        self.game_window = pygame.display.set_mode((FIELD_LENGTH + MARGIN_LTRB[1] + MARGIN_LTRB[3], FIELD_WIDTH +  MARGIN_LTRB[0] + MARGIN_LTRB[2]))
        self.player_surface = pygame.Surface(self.game_window.get_size(), pygame.SRCALPHA)
        
        # FPS (frames per second) controller
        self.fps_controller = pygame.time.Clock()
        ''' << Setup of pygame and colorama '''

    def terminate(self):
        printc('[INFO] Terminating current session', foreground=Fore.RED)
        time.sleep(3)
        pygame.quit()
        sys.exit()

    if __name__ == "__main__":
       pass

    def get_super_player_data(self):
        self.super_player_data_list = self.data_provider.get_super_players_from_play(self.play_data)

    def get_game_data(self):
        self.game_data = self.data_provider.get_game_by_id(self.game_id)

    def get_play_data(self):
        self.play_data = self.data_provider.get_play_by_id(self.game_id, self.play_id)

    def get_super_football_data(self):
        self.super_football_data = self.data_provider.get_super_football_data(self.game_id, self.play_id)

    def run(self):
        self.get_game_data()
        self.get_play_data()
        self.get_super_player_data()
        self.get_super_football_data()
        
        draw_football_field(self.game_window)
        frame_id = 1

        while True:
            draw_football_field(self.game_window)
            
            self.player_surface.fill(pygame.Color(0,0,0,0))
            for super_player in self.super_player_data_list:
                if super_player.is_frame_available(frame_id):
                    player_display_data = super_player.get_display_data(frame_id)
                    x, y, direction, speed, acceleration, mass = player_display_data.get_data()
                    color = TRANSPARENT_RED if super_player.get_team() == 'home' else TRANSPARENT_BLUE
                    draw_player(self.player_surface, x, y, direction, speed, acceleration, mass, color)
            self.game_window.blit(self.player_surface, (0, 0))
            
            if self.super_football_data.is_frame_available(frame_id):
                football_display_data = self.super_football_data.get_display_data(frame_id)
                x, y = football_display_data.get_coordinates()
                draw_football(self.game_window, x, y)
            
            pygame.display.update()
            time.sleep(0.1)
            
            frame_id += 1
            if(frame_id == self.super_football_data.get_frame_count()):
                frame_id = 1
            
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    self.terminate()
                # Whenever a key is pressed down
                elif event.type == pygame.KEYDOWN:
                    # Esc -> Create event to quit the game
                    if event.key == pygame.K_ESCAPE:
                        pygame.event.post(pygame.event.Event(pygame.QUIT))