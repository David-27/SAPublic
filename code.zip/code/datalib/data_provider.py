import pandas as pd
import numpy as np
from colorama import Fore, Style
from datalib.game_data import GameData
from datalib.play_data import PlayData
from datalib.player_data import PlayerData
from datalib.super_football_play_data import SuperFootballPlayData
from datalib.super_player_play_data import SuperPlayerPlayData
from util import printc

from errors.errors import DataNotAvailableError

class DataProvider:
    def __init__(self, years = [2018]):        
        self.years = years
        try:
            printc(f'[DataProvider]: loading data', foreground = Fore.BLUE)
            # NFL play data, plays from 2018 have a 2018* gameId, playId unique per game
            self.data_plays = pd.read_csv(r'./../data/plays.csv')
            
            # tracking data per year
            if 2018 in years:
                self.data_2018 = pd.read_csv(r'./../data/tracking2018.csv')
            if 2019 in years:
                self.data_2019 = pd.read_csv(r'./../data/tracking2019.csv')
            if 2020 in years:
                self.data_2020 = pd.read_csv(r'./../data/tracking2020.csv')
            
            # NFL player data
            self.data_players = pd.read_csv(r'./../data/players.csv')
            # NFL game data
            self.data_games = pd.read_csv(r'./../data/games.csv')
        except FileNotFoundError:
            printc('[Error] No such file or directory.', foreground = Fore.RED)
        printc(f'[DataProvider]: succesfully loaded\n > play data\n > player data\n > game data\n and > data for years {self.years}', foreground = Fore.GREEN)

    def is_tracking_data_available(self, year):
        return year in self.years
    
    def get_game_by_index(self, index = 0):
        df = self.data_games[index:(index+1)]
        game_data = GameData(df['gameId'].item())
        game_data.init_data(self.data_games.loc[self.data_games['gameId'] == df['gameId'].item()])
        return game_data
    
    def get_game_by_id(self, game_id):
        game_data = GameData(game_id)
        game_data.init_data(self.data_games.loc[self.data_games['gameId'] == game_id])
        return game_data
    
    def get_play_by_id(self, game_id, play_id):
        play_data = PlayData(game_id, play_id)
        play_data.init_data(self.data_plays.loc[(self.data_plays['gameId'] == 2018090600) & (self.data_plays['playId'] == 37)])
        return play_data
    
    def get_super_football_data(self, game_id, play_id):
        # games from 2018 have a 2018* gameId and so on
        # get tracking data to find football
        if str(game_id)[0:4] == '2018' and self.is_tracking_data_available(2018):
            play_tracking_data = self.data_2018.loc[(self.data_2018['gameId'] == game_id) & (self.data_2018['playId'] == play_id)]
        elif str(game_id)[0:4] == '2019' and self.is_tracking_data_available(2019):
            play_tracking_data = self.data_2019.loc[(self.data_2019['gameId'] == game_id) & (self.data_2019['playId'] == play_id)]
        elif str(game_id)[0:4] == '2020' and self.is_tracking_data_available(2020):
            play_tracking_data = self.data_2020.loc[(self.data_2020['gameId'] == game_id) & (self.data_2020['playId'] == play_id)]
        else:
            raise DataNotAvailableError("Data has not been found")

        football_tracking_data = play_tracking_data.loc[play_tracking_data['displayName'] == 'football']
        super_football_play_data =  SuperFootballPlayData(game_id, play_id)
        super_football_play_data.add_tracking_data(football_tracking_data)
        
        return super_football_play_data


    def get_super_players_from_play(self, play_data):
        game_id = play_data.game_id
        play_id = play_data.play_id

        # games from 2018 have a 2018* gameId and so on
        # get tracking data to find involved players
        if str(game_id)[0:4] == '2018' and self.is_tracking_data_available(2018):
            play_tracking_data = self.data_2018.loc[(self.data_2018['gameId'] == game_id) & (self.data_2018['playId'] == play_id)]
        elif str(game_id)[0:4] == '2019' and self.is_tracking_data_available(2019):
            play_tracking_data = self.data_2019.loc[(self.data_2019['gameId'] == game_id) & (self.data_2019['playId'] == play_id)]
        elif str(game_id)[0:4] == '2020' and self.is_tracking_data_available(2020):
            play_tracking_data = self.data_2020.loc[(self.data_2020['gameId'] == game_id) & (self.data_2020['playId'] == play_id)]
        else:
            raise DataNotAvailableError("Data has not been found")
        
        player_ids = play_tracking_data['nflId'].unique()
        player_ids = player_ids[~np.isnan(player_ids)]

        super_player_data_list = []
        
        for id in player_ids:
            player_data = PlayerData(id)
            player_data.init_data(self.data_players.loc[self.data_players['nflId'] == id])
            
            super_player_data = SuperPlayerPlayData(id, game_id, play_id)
            super_player_data.add_player_data(player_data)
            super_player_data.add_tracking_data(play_tracking_data.loc[play_tracking_data['nflId'] == id])
            super_player_data_list.append(super_player_data)
        
        return super_player_data_list
    
    def get_player_by_id(self, nfl_id):
        player_data = PlayerData(nfl_id)
        player_data.init_data(self.data_players.loc[self.data_players['nflId'] == nfl_id])
        return player_data
    
    def get_plays_from_game(self, game_id):
        all_plays = self.data_plays.loc[self.data_plays['gameId'] == game_id]
        return all_plays