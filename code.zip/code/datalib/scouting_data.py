class ScoutingData:
    # contains all the scouting data for a specific play
    # as represented by ~/data/PFFScoutingData.csv
    
    def __init__(self, game_id, play_id):
        self.game_id = game_id
        self.play_id = play_id
    
    def init_data(self, pandas_series):
        self.game_id = pandas_series['gameId'].item()
        self.play_id = pandas_series['playId'].item()
        self.snap_detail = pandas_series['snapDetail'].item()
        self.snap_time = pandas_series['snapTime'].item()
        self.operation_time = pandas_series['operationTime'].item()
        self.hang_time = pandas_series['hangTime'].item()
        self.kick_type = pandas_series['kickType'].item()
        self.kick_direction_intended = pandas_series['kickDirectionIntended'].item()
        self.kick_direction_actual = pandas_series['kickDirectionActual'].item()
        self.return_direction_intended = pandas_series['returnDirectionIntended'].item()
        self.return_direction_actual = pandas_series['returnDirectionActual'].item()
        self.missed_tackler = pandas_series['missedTackler'].item()
        self.assist_tackler = pandas_series['assistTackler'].item()
        self.tackler = pandas_series['tackler'].item()
        # self.kickoffReturnFormation = pandas_series['kickoffReturnFormation'].item()
        self.gunners = pandas_series['gunners'].item()
        self.punt_rushers = pandas_series['puntRushers'].item()
        self.special_teams_safeties = pandas_series['specialTeamsSafeties'].item()
        self.vises = pandas_series['vises'].item()
        self.kick_contact_type = pandas_series['kickContactType'].item()