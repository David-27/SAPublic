class PlayerDisplayData:
    # contains all the data needed to display a player at a given moment

    def __init__(self, x, y, direction, speed, acceleration, mass):
        self.x = x
        self.y = y
        self.direction = direction
        self.speed = speed
        self.acceleration = acceleration
        self.mass = mass
    
    def get_data(self):
        return self.x, self.y, self.direction, self.speed, self.acceleration, self.mass 