from datalib.football_display_data import FootballDisplayData
import numpy as np

class SuperFootballPlayData:
    # contains all data regarding the football of one play (location)

    def __init__(self, game_id, play_id):
        self.game_id = game_id
        self.play_id = play_id
        
    def add_tracking_data(self, pd_data_frame):
        self.tracking_data = pd_data_frame
    
    def get_frame_count(self):
        return np.amax(self.tracking_data['frameId'].values)
    
    def is_frame_available(self, frame_id):
        return frame_id in self.tracking_data['frameId'].values
    
    def get_display_data(self, frame_id):
        data = self.tracking_data.loc[self.tracking_data['frameId'] == frame_id]
        return FootballDisplayData(data['x'].item(), data['y'].item(), data['s'].item(), data['a'].item())