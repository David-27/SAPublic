import os
os.environ['PYGAME_HIDE_SUPPORT_PROMPT'] = "hide"

import math
import numpy as np
import pygame
from football.fb_constants import COORDINATE_SYSTEM_CENTER,  FOOTBALL_LENGTH, FOOTBALL_WIDTH, YARD
from football.math_constants import BASE_LINE_ACCELERATION, BASE_LINE_SPEED, FORCE_ADJUSTMENT
from pygamelib.pg_constants import BLACK, FOOTBALL_COLOR, TRANSPARENT_RED, WHITE
from pygamelib.pg_math import calculate_triangle_center, rotate_polygon, shift_polygon

def draw_football(game_window, x, y):
    # football dimensions: length 11" = 0.3 [yd], width 6.5" = 1.8 [yd]
    # draw football as <=>
    
    tr = translate_coordinates_to_pixels(x, y)
    x = tr[0]
    y = tr[1]
    
    pygame.draw.polygon(game_window, FOOTBALL_COLOR, 
        [[x - FOOTBALL_LENGTH / 2, y], [x - FOOTBALL_LENGTH / 4, y - FOOTBALL_WIDTH / 2],
        [x + FOOTBALL_LENGTH / 4, y - FOOTBALL_WIDTH / 2], [x + FOOTBALL_LENGTH / 2, y],
        [x + FOOTBALL_LENGTH / 4, y + FOOTBALL_WIDTH / 2], [x - FOOTBALL_LENGTH / 4, y + FOOTBALL_WIDTH / 2],
        [x - FOOTBALL_LENGTH / 2, y]])
    pygame.draw.polygon(game_window, WHITE, [[x - FOOTBALL_LENGTH / 4, y], [x + FOOTBALL_LENGTH / 4, y], [x - FOOTBALL_LENGTH / 4, y]], int(FOOTBALL_WIDTH / 5))

def draw_player(game_window, x, y, direction, speed, acceleration, mass, color = TRANSPARENT_RED):
    # idea: each player has a certain mass and acceleration, which yields a certain force
    # each player has a specific height
    # each player has a certain speed [yd/s]
    # => calculate a triangle pointing in the direction of the orientation
    # => the triangle is placed at (x,y) with its center (Innkreismittelpunkt)
    # => the height of the triangle depends on the speed
    # => the width of the triangle depends on acting force F = m*a
    # => the color of the triangle depends on the height
    # virtually construct triangle using the top left point as (0,0) pointing to the right
    
    if acceleration != 0:
        force = mass * acceleration / FORCE_ADJUSTMENT
    else:
        force = mass * BASE_LINE_ACCELERATION

    adjusted_speed = BASE_LINE_SPEED + speed

    bottom_left = [0,0]
    top_left = [0, force]
    right = [adjusted_speed, force / 2]
    points = [top_left, right, bottom_left]
    
    center = calculate_triangle_center(points)
    rotation = convert_orientation_to_rotation(direction)
    rotated_points = rotate_polygon(points, rotation, center)
    shift = np.subtract(np.array([x, y]), np.array(center))
    shifted_points = shift_polygon(shift, rotated_points)

    translated_points = translate_coordinate_list_to_pixels(shifted_points)
    pygame.draw.polygon(game_window, color, translated_points)
    pygame.draw.lines(game_window, BLACK, False, translated_points)
    
    
    


'''
Visualization of the playing field and the [data] coordiates

(0, 53.3)                               (120. 53.3)
            _ _ _ _ _ _ _  _ _ _ _ _ _ _
  y ^      | |           |            | |
    |      | |           |            | |
    |      | |           |            | |
    |      |_|_ _ _ _ _ _|_ _ _ _ _ __|_|
(0, 0)                                  (120, 0)
           -----------------------------> x
'''

def translate_coordinates_to_pixels(x, y):
        pixel_coordinates = [COORDINATE_SYSTEM_CENTER[0] + x * YARD, COORDINATE_SYSTEM_CENTER[1] - y * YARD]
        return pixel_coordinates

def translate_coordinate_list_to_pixels(points):
        translated = []
        for point in points:
            translated_point = translate_coordinates_to_pixels(point[0], point[1])
            translated.append(translated_point)
        return translated

def convert_orientation_to_rotation(orientation):
        # 0°    =>  pi/2 = -1.5pi
        # 90°   =>  0
        # 180°  => -pi   =  pi
        # 270°  => -pi   =  pi
        angle = (orientation / 360) * 2 * math.pi
        return - angle + math.pi / 2

