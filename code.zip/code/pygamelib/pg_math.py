import os
os.environ['PYGAME_HIDE_SUPPORT_PROMPT'] = "hide"

import numpy as np
import math

def rotate_polygon(points, degree, center = [0, 0]):
    if degree == 0 or degree % (2 * math.pi) == 0:
        return points
    matrix = get_rotation_matrix(degree)
    rotated_points = []
    for point in points:
        shifted_point = np.subtract(np.array(point), np.array(center))
        shifted_rotated_point = np.matmul(matrix, shifted_point)
        rotated_point = np.add(shifted_rotated_point, center)
        rotated_points.append(rotated_point.tolist())
    return rotated_points
        

def get_rotation_matrix(rotation):
    # given an angle a (counter-clockwise) and a vector v^T = [x, y]
    # v_r = [cos(a), -sin(a)  [x,
    #        sin(a),  cos(a)]  y]
    return np.array([
        [math.cos(rotation), -math.sin(rotation)],
        [math.sin(rotation), math.cos(rotation)]
    ], dtype=float)

def calculate_triangle_center(points):
    # given a triangle [P_1,P_2,P_3]
    # s_1 corresponds to [P_2, P_3] etc.
    # s_1 = sqrt[((x_P_2 - x_P_3)^2) + ((y_P_1 - y_P_3)^2)]
    # NOTE: correctness confirmed [_/]

    P_1 = points[0]
    P_2 = points[1]
    P_3 = points[2]
    
    s_1 = math.sqrt(math.pow(P_2[0] - P_3[0],2) + (math.pow(P_2[1] - P_3[1],2)))
    s_2 = math.sqrt(math.pow(P_1[0] - P_3[0],2) + (math.pow(P_1[1] - P_3[1],2)))
    s_3 = math.sqrt(math.pow(P_1[0] - P_2[0],2) + (math.pow(P_1[1] - P_2[1],2)))
    
    c_x = (s_1 * P_1[0] + s_2 * P_2[0] + s_3 * P_3[0]) / (s_1 + s_2 + s_3)
    c_y = (s_1 * P_1[1] + s_2 * P_2[1] + s_3 * P_3[1]) / (s_1 + s_2 + s_3)

    return [c_x, c_y]

def shift_polygon(shift, points):
    shifted_points = []
    for point in points:
        shifted_point = np.add(np.array(shift), np.array(point))
        shifted_points.append(shifted_point)
    return shifted_points