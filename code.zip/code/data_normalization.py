import math
import pandas as pd
import numpy as np
import colorama
from colorama import Fore, Style
import sys

from datalib.punt_data_provider import PuntDataProvider

DATA_PATH = 'C:/Users/user/Studienarbeit/data/'

def transform_angle(angle):
    return (math.pi / 2) - ((angle/360) * 2 * math.pi)

def apply_sin(angle):
    return math.sin(angle)

def apply_cos(angle):
    return math.cos(angle)


colorama.init()
data_provider = PuntDataProvider(load_tracking_data_as_normalized=False, prefix=DATA_PATH)
df = data_provider.data_tracking.copy(deep=True)


df['outlier'] = False

# mask too fast players as outliers
outlier_mask = (df['displayName'] != 'football') & ((df['deltaX']**2 + df['deltaY']**2) > (1.05**2))
df.loc[outlier_mask, 'outlier'] = True

# mask too fast football frames as outliers
outlier_mask = (df['displayName'] == 'football') & ((df['deltaX']**2 + df['deltaY']**2) > (3.42**2))
df.loc[outlier_mask, 'outlier'] = True


df['sCopyX'] = df['dir']
df['sCopyY'] = df['dir']

df['sCopyX'] = df['sCopyX'].apply(transform_angle)
df['sCopyY'] = df['sCopyY'].apply(transform_angle)

df['sCopyX'] = df['sCopyX'].apply(apply_cos)
df['sCopyY'] = df['sCopyY'].apply(apply_sin)

df['sCopyX'] = df['sCopyX'] * df['s']
df['sCopyY'] = df['sCopyY'] * df['s']

df['sX'] = df['sCopyX']
df['sY'] = df['sCopyY']
df.drop(['sCopyX', 'sCopyY'], axis = 1, inplace = True)

football_mask = (df['displayName'] == 'football')
df.loc[football_mask, 'sX'] = df.loc[football_mask, 'deltaX'] * 10
df.loc[football_mask, 'sY'] = df.loc[football_mask, 'deltaY'] * 10


# mask all data points beyond the playing field as outliers
outlier_mask = (df['x'] < 0) | (df['x'] > 120)
df.loc[outlier_mask, 'outlier'] = True

outlier_mask = (df['y'] < 0) | (df['y'] > 53.333)
df.loc[outlier_mask, 'outlier'] = True


# # normalize all data in a linear fashion
# df['x'] /= 120
# df['y'] /= 120
# 
# df['deltaX'] += 120
# df['deltaX'] /= 240
# 
# df['deltaY'] += 120
# df['deltaY'] /= 240
# 
# df['sX'] += 120
# df['sX'] /= 240
# 
# df['sY'] += 120
# df['sY'] /= 240
# 
# outlier_mask = (df['x'] < 0) | (df['x'] > 1)
# df.loc[outlier_mask, 'outlier'] = True
# 
# outlier_mask = (df['y'] < 0) | (df['y'] > 0.444417)
# df.loc[outlier_mask, 'outlier'] = True

df.drop(['time'],axis=1, inplace=True)

df.to_csv(f'{DATA_PATH}punts_tracking_normalized.csv')


