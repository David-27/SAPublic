class GameData:
    # contains all data of a game as represented by ~/data/games.csv

    # def __init__(self, game_id, season, week, game_time_eastern, home_team_abbr, visitor_team_abbr):
    #     self.game_id = game_id
    #     self.season = season
    #     self.week = week
    #     self.game_time_eastern = game_time_eastern
    #     self.home_team_abbr = home_team_abbr
    #     self.visitor_team_abbr = visitor_team_abbr

    def __init__(self, game_id):
        self.game_id = game_id
    
    def init_data(self, pandas_series):
        self.game_id = pandas_series['gameId'].item()
        self.season = pandas_series['season'].item()
        self.week = pandas_series['week'].item()
        self.game_time_eastern = pandas_series['gameTimeEastern'].item()
        self.home_team_abbr = pandas_series['homeTeamAbbr'].item()
        self.visitor_team_abbr = pandas_series['visitorTeamAbbr'].item()
    
    def get_home_team(self):
        return self.home_team_abbr
    
    def get_visitor_team(self):
        return self.visitor_team_abbr