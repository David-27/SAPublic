import numpy as np
import os

DATA_PATH_IN = 'C:/Users/user/Studienarbeit/data/npy'
DATA_PATH_OUT = 'C:/Users/user/Studienarbeit/data/F'

if not os.path.exists(DATA_PATH_OUT):
    os.mkdir(DATA_PATH_OUT)

collector_X_eval_only = []
collector_y_eval_only = []
collector_id_eval_only = []
collector_flag_eval_only = []

collector_X_tr = []
collector_y_tr = []
collector_id_tr = []
collector_flag_tr = []

for i in range(1,5):
    X_all = np.load(f'{DATA_PATH_IN}/section{i}_XFt.npy')
    y_all = np.load(f'{DATA_PATH_IN}/section{i}_yFt.npy')
    ids_all = np.load(f'{DATA_PATH_IN}/section{i}_idsFt.npy')
    flags = np.load(f'{DATA_PATH_IN}/section{i}_flagsFt.npy')

    for X, y, id, flag in zip(X_all, y_all, ids_all, flags):
        if not(flag):
            collector_X_eval_only.append(X)
            collector_y_eval_only.append(y)
            collector_id_eval_only.append(id)
            collector_flag_eval_only.append(flag)
        else:
            collector_X_tr.append(X)
            collector_y_tr.append(y)
            collector_id_tr.append(id)
            collector_flag_tr.append(flag)


np.save(f'{DATA_PATH_OUT}/collector_X_tr', collector_X_tr)
np.save(f'{DATA_PATH_OUT}/collector_y_tr', collector_y_tr)
np.save(f'{DATA_PATH_OUT}/collector_id_tr', collector_id_tr)
np.save(f'{DATA_PATH_OUT}/collector_flag_tr', collector_flag_tr)

np.save(f'{DATA_PATH_OUT}/collector_X_eval_only', collector_X_eval_only)
np.save(f'{DATA_PATH_OUT}/collector_y_eval_only', collector_y_eval_only)
np.save(f'{DATA_PATH_OUT}/collector_id_eval_only', collector_id_eval_only)
np.save(f'{DATA_PATH_OUT}/collector_flag_eval_only', collector_flag_eval_only)