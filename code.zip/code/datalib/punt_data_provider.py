from os import error
from dateutil import parser
import pandas as pd
import numpy as np
import colorama
from colorama import Fore, Style
from datalib.game_data import GameData
from datalib.play_data import PlayData
from datalib.player_data import PlayerData
from datalib.scouting_data import ScoutingData
from datalib.super_football_play_data import SuperFootballPlayData
from datalib.super_player_play_data import SuperPlayerPlayData
from util import printc


class PuntDataProvider:
    def __init__(self, load_tracking_as_adjusted = True, load_tracking_as_adjusted_expanded = True, load_tracking_data_as_normalized = True, load_plays_as_enhanced=True, prefix=r'C://Users/user/Studienarbeit/data/'):
        colorama.init()

        self.load_plays_as_enhanced = load_plays_as_enhanced

        printc(f'[PuntDataProvider]: loading data...', foreground = Fore.BLUE)
        missing_files = 0

        try:
            # NFL punt play data, plays from 2018 have a 2018* gameId, playId unique per game
            if load_plays_as_enhanced:
                file = prefix + r'punts_plays_enhanced.csv'
                self.data_plays = pd.read_csv(file)
                printc(f'[PuntDataProvider]: successfully loaded > ENHANCED (default) punt play data...', foreground = Fore.GREEN)
            else:
                file = prefix + r'punts_plays.csv'
                self.data_plays = pd.read_csv(file)
                printc(f'[PuntDataProvider]: successfully loaded > punt play data...', foreground = Fore.GREEN)
        except FileNotFoundError:
            printc('[Error] No such file or directory: ' + file, foreground = Fore.RED)
            missing_files += 1
            
        try:
            # NFL punt play tracking data
            if load_tracking_as_adjusted and load_tracking_as_adjusted_expanded and load_tracking_data_as_normalized:
                file = prefix + r'punts_tracking_normalized.csv'
                self.data_tracking = pd.read_csv(file)
                printc(f'[PuntDataProvider]: successfully loaded > ADJUSTED, EXPANDED, NORMALIZED (default) punt tracking data...', foreground = Fore.GREEN)
            elif load_tracking_as_adjusted and load_tracking_as_adjusted_expanded:
                file = prefix + r'punts_tracking_adjusted_expanded.csv'
                self.data_tracking = pd.read_csv(file)
                printc(f'[PuntDataProvider]: successfully loaded > ADJUSTED and EXPANDED punt tracking data...', foreground = Fore.GREEN)
            elif load_tracking_as_adjusted:
                file = prefix + r'punts_tracking_adjusted.csv'
                self.data_tracking = pd.read_csv(file)
                printc(f'[PuntDataProvider]: successfully loaded > ADJUSTED punt tracking data...', foreground = Fore.GREEN)
            else:
                file = prefix + r'punts_tracking.csv'
                self.data_tracking = pd.read_csv(file)
                printc(f'[PuntDataProvider]: successfully loaded > punt tracking data...', foreground = Fore.GREEN)
        except FileNotFoundError:
            printc('[Error] No such file or directory: ' + file, foreground = Fore.RED)
            missing_files += 1

        try:   
            # NFL punt player data
            file = prefix + r'punts_players.csv'
            self.data_players = pd.read_csv(file)
            printc(f'[PuntDataProvider]: successfully loaded > punt player data...', foreground = Fore.GREEN)
        except FileNotFoundError:
            printc('[Error] No such file or directory: ' + file, foreground = Fore.RED)
            missing_files += 1

        try:
            # NFL game data
            file = prefix + r'games.csv'
            self.data_games = pd.read_csv(file)
            printc(f'[PuntDataProvider]: successfully loaded > punt game data...', foreground = Fore.GREEN)
        except FileNotFoundError:
            printc('[Error] No such file or directory: ' + file, foreground = Fore.RED)
            missing_files += 1

        try:    
            # NFL scouting data
            file = prefix + r'punts_PFFScoutingData.csv'
            self.data_scouting = pd.read_csv(file)
            printc(f'[PuntDataProvider]: successfully loaded > punt scouting data...', foreground = Fore.GREEN)
        except FileNotFoundError:
            printc('[Error] No such file or directory: ' + file, foreground = Fore.RED)
            missing_files += 1

        if missing_files > 0:
            if missing_files == 5:
                printc('[Error] Initialization failed.', foreground = Fore.RED)
            else:
                printc('[Warning] Initialization incomplete.', foreground = Fore.YELLOW)
                printc(f'[Warning] Could not find {missing_files}/5 files.', foreground = Fore.YELLOW)
        else:
            printc(f'[PuntDataProvider]: Loaded 5/5 files.', foreground = Fore.GREEN)  
            printc(f'[PuntDataProvider]: successfully completed initialization.', foreground = Fore.GREEN)

    def get_game_by_index(self, index = 0):
        df = self.data_games[index:(index+1)]
        game_data = GameData(df['gameId'].item())
        game_data.init_data(self.data_games.loc[self.data_games['gameId'] == df['gameId'].item()])
        return game_data

    def get_play_by_index(self, index = 0):
        df = self.data_plays[index:(index+1)]
        play_data = PlayData(df['gameId'].item(), df['playId'].item())
        play_data.init_data(self.data_plays.loc[(self.data_plays['gameId'] == df['gameId'].item()) & (self.data_plays['playId'] == df['playId'].item())])
        return play_data
    
    def get_game_by_id(self, game_id):
        game_data = GameData(game_id)
        game_data.init_data(self.data_games.loc[self.data_games['gameId'] == game_id])
        return game_data
    
    def get_play_by_id(self, game_id, play_id):
        play_data = PlayData(game_id, play_id, enhanced=self.load_plays_as_enhanced)
        play_data.init_data(self.data_plays.loc[(self.data_plays['gameId'] == game_id) & (self.data_plays['playId'] == play_id)])
        return play_data
    
    def get_super_football_data(self, game_id, play_id):
        # get tracking data to find football
        play_tracking_data = self.data_tracking.loc[(self.data_tracking['gameId'] == game_id) & (self.data_tracking['playId'] == play_id)]
        football_tracking_data = play_tracking_data.loc[play_tracking_data['displayName'] == 'football']
        super_football_play_data =  SuperFootballPlayData(game_id, play_id)
        super_football_play_data.add_tracking_data(football_tracking_data)
        
        return super_football_play_data


    def get_super_players_from_play(self, game_id, play_id):
        # get tracking data to find involved players
        play_tracking_data = self.data_tracking.loc[(self.data_tracking['gameId'] == game_id) & (self.data_tracking['playId'] == play_id)]
        player_ids = play_tracking_data['nflId'].unique()
        player_ids = player_ids[~np.isnan(player_ids)]

        super_player_data_list = []
        
        for id in player_ids:
            player_data = PlayerData(id)
            player_data.init_data(self.data_players.loc[self.data_players['nflId'] == id])
            
            super_player_data = SuperPlayerPlayData(id, game_id, play_id)
            super_player_data.add_player_data(player_data)
            super_player_data.add_tracking_data(play_tracking_data.loc[play_tracking_data['nflId'] == id])
            super_player_data_list.append(super_player_data)
        
        return super_player_data_list
    
    def get_player_by_id(self, nfl_id):
        player_data = PlayerData(nfl_id)
        player_data.init_data(self.data_players.loc[self.data_players['nflId'] == nfl_id])
        return player_data
    
    def get_scouting_data_by_id(self, game_id, play_id):
        scouting_data = ScoutingData(game_id, play_id)
        scouting_data.init_data(self.data_scouting.loc[(self.data_scouting['gameId'] == game_id) & (self.data_scouting['playId'] == play_id)])
        return scouting_data
    
    def get_plays_from_game(self, game_id):
        all_plays = self.data_plays.loc[self.data_plays['gameId'] == game_id]
        return all_plays
    
    def generate_training_data_from_play(self, game_id, play_id, intervall = 10):
        # intervall = 10 means the previous 9 frames are used to predict the tenth (label) frame

        super_football_data = self.get_super_football_data(game_id, play_id)
        play = self.get_play_by_id(game_id, play_id)

        super_players_data = self.get_super_players_from_play(play)
        sorted_players = self.sort_super_players(game_id, play_id, super_players_data)
        relev_data_players = [self.get_relevant_player_tracking_data(p) for p in sorted_players]
        relev_data_football = self.get_relevant_football_tracking_data(super_football_data)

        collection_relev_data = [*relev_data_players, relev_data_football]
        relev_df = pd.concat(collection_relev_data, axis = 1)

        X = []
        y = []

        for i in range(intervall, relev_df.shape[0]):
            # NOTE: inclusive indexes when using .iloc
            X.append(relev_df.iloc[i-intervall:i-1].to_numpy())
            y.append(relev_df.iloc[i].to_numpy())

        return X, y

    def sort_super_players(self, game_id, play_id, super_player_list):
        team_in_possession = self.find_team_in_possession(game_id, play_id)

        sort_info_away = {'y': [], 'nflId': []}
        sort_info_home = {'y': [], 'nflId': []}

        # acquire sorting information
        for super_player in super_player_list:
            tr_data = super_player.tracking_data
            sorting_info = tr_data[['x', 'y', 'nflId', 'team']].iloc[0]
            if sorting_info['team'] == 'home':
                sort_info_home['y'].append(sorting_info['y'])
                sort_info_home['nflId'].append(sorting_info['nflId'])
            else:
                sort_info_away['y'].append(sorting_info['y'])
                sort_info_away['nflId'].append(sorting_info['nflId'])

        away_df = pd.DataFrame(sort_info_away)
        home_df = pd.DataFrame(sort_info_home)

        sorted_away_df = away_df.sort_values(by='y')
        sorted_home_df = home_df.sort_values(by='y')

        sorted_players_away = []
        sorted_players_home = []

        for nfl_id in sorted_away_df['nflId']:
            for super_player in super_player_list:
                if super_player.player.nfl_id == nfl_id:
                    sorted_players_away.append(super_player)
        for nfl_id in sorted_home_df['nflId']:
            for super_player in super_player_list:
                if super_player.player.nfl_id == nfl_id:
                    sorted_players_home.append(super_player)

        if team_in_possession == 'home':
            return [*sorted_players_home, *sorted_players_away]
        else:
            return [*sorted_players_away, *sorted_players_home]
    

    def find_team_in_possession(self, game_id, play_id):
        game_data = self.get_game_by_id(game_id)
        play_data = self.get_play_by_id(game_id, play_id)
        if play_data.possession_team == game_data.home_team_abbr:
            return 'home'
        else:
            return 'away'

    def encode_play_direction(self, direction):
        if direction == 'left':
            return -1
        else:
            return 1
    
    def calculate_age_in_years(self, time_of_play, birth_day):
        play = parser.parse(time_of_play)
        bday = parser.parse(birth_day)
        delta_years = play.year - bday.year
        delta_months = play.month - bday.month
        if delta_months < 0:
            return delta_years - 1
        else:
            delta_days = play.day - bday.day
            if delta_days < 0:
                return delta_years - 1
        return delta_years

    def calculate_height_in_inches(self, height_str):
        # example string: '6-0' meaning 6' 0''
        if '-' in height_str:
            str_arr = height_str.split('-')
            height_component_feet = int(str_arr[0])
            height_component_inches = int(str_arr[1])
            return height_component_feet * 12.0 + height_component_inches * 1.0
        else:
            return int(height_str) * 1.0
    

    def get_relevant_player_tracking_data(self, super_player):
        tr_data = super_player.tracking_data
        play_time = tr_data['time'].iloc[0]

        dic = {'age': self.calculate_age_in_years(play_time, super_player.player.birth_date),
               'height': self.calculate_height_in_inches(super_player.player.height),
               'weight': super_player.player.weight}

        relevant_tr_data = super_player.tracking_data[['x', 'y', 's', 'a', 'dis', 'o', 'dir']]
        relevant_data = pd.concat([relevant_tr_data, pd.DataFrame(dic, index = relevant_tr_data.index)], axis = 1)
        relevant_data = relevant_data.reset_index(drop = True)
        return relevant_data

    def get_relevant_football_tracking_data(self, super_football):
        tr_data = super_football.tracking_data
        dic = {'playDirection': self.encode_play_direction(tr_data['playDirection'].iloc[0])}

        # insert z value as column here
    
        relevant_tr_data = super_football.tracking_data[['x', 'y', 's', 'a', 'dis']]
        relevant_data = pd.concat([relevant_tr_data, pd.DataFrame(dic, index = relevant_tr_data.index)], axis = 1)
        relevant_data = relevant_data.reset_index(drop = True)
        return relevant_data
    
    def find_team_in_possession(self, game_id, play_id):
        game_data = self.get_game_by_id(game_id)
        play_data = self.get_play_by_id(game_id, play_id)
        if play_data.possession_team == game_data.home_team_abbr:
            return 'home'
        else:
            return 'away'
