class PlayData:
    # contains all data of a play as represented by ~/data/plays.csv

    def __init__(self, game_id, play_id, enhanced=True):
        self.game_id = game_id
        self.play_id = play_id
        self.enhanced = enhanced
    
    def init_data(self, pandas_series):
        self.play_description = pandas_series['playDescription']
        self.quarter = pandas_series['quarter'].item()
        self.down = pandas_series['down'].item()
        self.yards_to_go = pandas_series['yardsToGo'].item()
        self.possession_team = pandas_series['possessionTeam'].item()
        self.special_teams_play_type = pandas_series['specialTeamsPlayType'].item()
        self.special_teams_result = pandas_series['specialTeamsResult'].item()
        self.kicker_id = pandas_series['kickerId'].item()
        self.returner_id = pandas_series['returnerId'].item()
        self.kick_blocker_id = pandas_series['kickBlockerId'].item()
        self.yardline_side = pandas_series['yardlineSide'].item()
        self.yardline_number = pandas_series['yardlineNumber'].item()
        self.game_clock = pandas_series['gameClock'].item()
        self.penalty_codes = pandas_series['penaltyCodes'].item()
        self.penalty_jersey_numbers = pandas_series['penaltyJerseyNumbers'].item()
        self.penalty_yards = pandas_series['penaltyYards'].item()
        self.pre_snap_home_score = pandas_series['preSnapHomeScore'].item()
        self.pre_snap_visitor_score = pandas_series['preSnapVisitorScore'].item()
        self.pass_result = pandas_series['passResult'].item()
        self.kick_length = pandas_series['kickLength'].item()
        self.kick_return_yardage = pandas_series['kickReturnYardage'].item()
        self.play_result = pandas_series['playResult'].item()
        self.absolute_yardline_number = pandas_series['absoluteYardlineNumber'].item()

        # enhanced features
        if self.enhanced:
            self.snap = pandas_series['snap'].item()
            self.punt = pandas_series['punt'].item()
            self.reception = pandas_series['reception'].item()

        
    # def __init__(self, game_id, play_id, play_description, quarter, down, yards_to_go, possession_team, special_teams_play_type, special_teams_result, kicker_id, returner_id, kick_blocker_id, yardline_side, yardline_number, game_clock,	penalty_codes, penalty_jersey_numbers, penalty_yards, pre_snap_home_score, pre_snap_visitor_score, pass_result, kick_length, kick_return_yardage, play_result, absolute_yardline_number):
    #     self.game_id = game_id
    #     self.play_id = play_id
    #     self.play_description = play_description
    #     self.quarter = quarter
    #     self.down = down
    #     self.yards_to_go = yards_to_go
    #     self.possession_team = possession_team
    #     self.special_teams_play_type = special_teams_play_type
    #     self.special_teams_result = special_teams_result
    #     self.kicker_id = kicker_id
    #     self.returner_id = returner_id
    #     self.kick_blocker_id = kick_blocker_id
    #     self.yardline_side = yardline_side
    #     self.yardline_number = yardline_number
    #     self.game_clock = game_clock
    #     self.penalty_codes = penalty_codes
    #     self.penalty_jersey_numbers = penalty_jersey_numbers
    #     self.penalty_yards = penalty_yards
    #     self.pre_snap_home_score = pre_snap_home_score
    #     self.pre_snap_visitor_score = pre_snap_visitor_score
    #     self.pass_result = pass_result
    #     self.kick_length = kick_length
    #     self.kick_return_yardage = kick_return_yardage
    #     self.play_result = play_result
    #     self.absolute_yardline_number = absolute_yardline_number