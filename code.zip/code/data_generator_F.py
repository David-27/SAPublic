import datetime
import colorama
import pandas as pd
from datalib.punt_data_provider import PuntDataProvider
import numpy as np
import os

colorama.init()

DATA_PATH = 'C:/Users/user/Studienarbeit/data/'
if not os.path.exists(f'{DATA_PATH}F'):
    os.mkdir(f'{DATA_PATH}F')
   
data_provider = PuntDataProvider(prefix=DATA_PATH)

def is_penalty_on_play(game_id, play_id):
    df = data_provider.data_plays
    a = df.loc[(df['penaltyCodes'].notna()) & (df['gameId'] == game_id) & (df['playId'] == play_id)]
    return not(a.empty)

def is_eval_only_sample(game_id, play_id, player_id):
    df = pd.read_csv(DATA_PATH+'exclusions.csv')
    # 0 = player_id, 1 = game_id, 2 = play_id
    a = df.loc[(df['nflId'] == player_id) & (df['gameId'] == game_id) & (df['playId'] == play_id)]
    return a.empty

def get_jersey_numbers_gunners(game_id, play_id):
    sc_data = data_provider.get_scouting_data_by_id(game_id, play_id)
    gunner_str = sc_data.gunners
    str_list = gunner_str.split('; ')
    
    game = data_provider.get_game_by_id(game_id)
    teamPuntingAbbr = game.get_home_team() if (data_provider.find_team_in_possession(game_id, play_id) == 'home') else game.get_visitor_team()
    
    jersey_numbers = []
    for s in str_list:
        number = s[len(teamPuntingAbbr)+1:]
        jersey_numbers.append(number)
    
    return jersey_numbers

def find_returner_nfl_id_and_jersey_number(game_id, play_id):
    players = data_provider.get_super_players_from_play(game_id, play_id)
    xs = []
    
    for player in players:
        x, y = player.get_starting_position()
        xs.append(x)
    
    index = xs.index(max(xs))
    jersey_number = players[index].tracking_data['jerseyNumber'].unique()[0]
    nfl_id = players[index].tracking_data['nflId'].unique()[0]
    
    return nfl_id, jersey_number

def calculate_data_matrices_gunner(game_id, play_id, gunner_jersey, frames=None, shuffle=False, verbose=False):
    _, returner_jersey = find_returner_nfl_id_and_jersey_number(game_id, play_id)
    # home_team_jerseys, away_team_jerseys = get_jersey_numbers_by_team(play.game_id, play.play_id)
    
    team_in_possession = data_provider.find_team_in_possession(game_id, play_id)
    players = data_provider.get_super_players_from_play(game_id, play_id)
    
    # map all jersey numbers to the respective players and teams
    offense_map = dict()
    defense_map = dict()
    
    for player in players:
        jersey_number = player.get_jersey_number()
        team = player.get_team()
        if team_in_possession == team:
            offense_map[jersey_number] = player
        else:
            defense_map[jersey_number] = player
    
    if frames == None:
        frames = [players[0].tracking_data['frameId'].values[0], players[0].tracking_data['frameId'].values[-1]]
    
    matrix_collector = []
    label_collector = []
    nfl_id_collector = []
    flag_collector = []

    
    for frame in range(frames[0], frames[1]+1):
        detected_nan = False
        try:
            # calculate the speed and positions for all players of the offense at that moment
            offense_x = []
            offense_y = []
            offense_speed_x = []
            offense_speed_y = []
            
            for player in offense_map.values():
                if int(player.get_jersey_number()) == int(gunner_jersey):
                    gunner = player
                    delta_x, delta_y = gunner.get_deltas(frame, verbose=False)
                    nfl_id = gunner.nfl_id
                    if np.isnan([delta_x, delta_y]).any():
                        detected_nan = True
                        break
                
                x, y, s_x, s_y = player.get_position_and_speed(frame, verbose=False)
                offense_x.append(x)
                offense_y.append(y)
                offense_speed_x.append(s_x)
                offense_speed_y.append(s_y)

            if detected_nan and verbose:
                print(f'{str(datetime.datetime.now())}   Detected NaN Value in deltas: {game_id}, playId: {play_id}, frame: {frame}')
                print(f'{str(datetime.datetime.now())}   Deltas: {delta_x} | {delta_y}')
                continue

            offense_x = np.array(offense_x)
            offense_y = np.array(offense_y)
            offense_speed_x = np.array(offense_speed_x)
            offense_speed_y = np.array(offense_speed_y)

            # calculate the speed and positions for all players of the defense without returner at that moment
            defense_x = []
            defense_y = []
            defense_speed_x = []
            defense_speed_y = []
            
            for player in defense_map.values():
                if player.get_jersey_number() == returner_jersey:
                    returner = player
                    continue
                
                x, y, s_x, s_y = player.get_position_and_speed(frame, verbose=False)

                defense_x.append(x)
                defense_y.append(y)
                defense_speed_x.append(s_x)
                defense_speed_y.append(s_y)

            defense_x = np.array(defense_x)
            defense_y = np.array(defense_y)
            defense_speed_x = np.array(defense_speed_x)
            defense_speed_y = np.array(defense_speed_y)

            gunner_x, gunner_y, gunner_s_x, gunner_s_y = gunner.get_position_and_speed(frame, verbose=False)
            ret_x, ret_y, ret_s_x, ret_s_y = returner.get_position_and_speed(frame, verbose=False)

            # 14 values x 10 defense players x 11 offense players
            # values: off s_x, off s_y, off x - ret x, off y - ret y, off s_x - ret s_x, off s_y - ret s_y 
            #         off x - def x, off y - def y, off s_x - def s_x, off s_y - def s_y, 
            #         off x - gun x, off y - gun y, off s_x - gun s_x, off s_y - gun s_y
            # value count: 14

            plane_collector = []
            row_collector = []
            row = []

            # value No. 1 : Speed of the offense in x direction
            row_collector = []
            for _ in range(0, 10):
                row_collector.append(offense_x)
            row_collector = np.array(row_collector)
            plane_collector.append(row_collector)

            # value No. 2 : Speed of the offense in y direction
            row_collector = []
            for _ in range(0, 10):
                row_collector.append(offense_y)
            row_collector = np.array(row_collector)
            plane_collector.append(row_collector)

            # value No. 3 : offense x - returner x
            row_collector = []
            vals = offense_x - ret_x
            for _ in range(0, 10):
                row_collector.append(vals)
            row_collector = np.array(row_collector)
            plane_collector.append(row_collector)

            # value No. 4 : offense y - returner y
            row_collector = []
            vals = offense_y - ret_y
            for _ in range(0, 10):
                row_collector.append(vals)
            row_collector = np.array(row_collector)
            plane_collector.append(row_collector)

            # value No. 5 : offense speed x - returner speed x
            row_collector = []
            vals = offense_speed_x - ret_s_x
            for _ in range(0, 10):
                row_collector.append(vals)
            row_collector = np.array(row_collector)
            plane_collector.append(row_collector)

            # value No. 6 : offense speed y - returner speed y
            row_collector = []
            vals = offense_speed_y - ret_s_y
            for _ in range(0, 10):
                row_collector.append(vals)
            row_collector = np.array(row_collector)
            plane_collector.append(row_collector)

            # value No. 7 : offense x - defense x
            offense_plane = []         # 10 x 11
            defense_plane = []         # 11 x 10
            for _ in range(0, 10):
                offense_plane.append(offense_x)
                defense_plane.append(defense_x)
            defense_plane.append(defense_x)

            offense_plane = np.array(offense_plane)
            defense_plane = np.array(defense_plane)
            defense_plane = defense_plane.T

            result = offense_plane - defense_plane
            plane_collector.append(result)

            # value No. 8 : offense y - defense y
            offense_plane = []         # 10 x 11
            defense_plane = []         # 11 x 10
            for _ in range(0, 10):
                offense_plane.append(offense_y)
                defense_plane.append(defense_y)
            defense_plane.append(defense_y)

            offense_plane = np.array(offense_plane)
            defense_plane = np.array(defense_plane)
            defense_plane = defense_plane.T

            result = offense_plane - defense_plane
            plane_collector.append(result)

            # value No. 9 : offense speed x - defense speed x
            offense_plane = []         # 10 x 11
            defense_plane = []         # 11 x 10
            for _ in range(0, 10):
                offense_plane.append(offense_speed_x)
                defense_plane.append(defense_speed_x)
            defense_plane.append(defense_speed_x)

            offense_plane = np.array(offense_plane)
            defense_plane = np.array(defense_plane)
            defense_plane = defense_plane.T

            result = offense_plane - defense_plane
            plane_collector.append(result)

            # value No. 10 : offense speed y - defense speed y
            offense_plane = []         # 10 x 11
            defense_plane = []         # 11 x 10
            for _ in range(0, 10):
                offense_plane.append(offense_speed_y)
                defense_plane.append(defense_speed_y)
            defense_plane.append(defense_speed_x)

            offense_plane = np.array(offense_plane)
            defense_plane = np.array(defense_plane)
            defense_plane = defense_plane.T

            result = offense_plane - defense_plane
            plane_collector.append(result)

            # value No. 11 : offense x - gunner x
            row_collector = []
            vals = offense_x - gunner_x
            for _ in range(0, 10):
                row_collector.append(vals)
            row_collector = np.array(row_collector)
            plane_collector.append(row_collector)

            # value No. 12 : offense y - gunner y
            row_collector = []
            vals = offense_y - gunner_y
            for _ in range(0, 10):
                row_collector.append(vals)
            row_collector = np.array(row_collector)
            plane_collector.append(row_collector)

            # value No. 13 : offense speed x - gunner speed x
            row_collector = []
            vals = offense_speed_x - gunner_s_x
            for _ in range(0, 10):
                row_collector.append(vals)
            row_collector = np.array(row_collector)
            plane_collector.append(row_collector)

            # value No. 14 : offense speed y - gunner speed y
            row_collector = []
            vals = offense_speed_y - gunner_s_y
            for _ in range(0, 10):
                row_collector.append(vals)
            row_collector = np.array(row_collector)
            plane_collector.append(row_collector)

            matrix = np.array(plane_collector)
            matrix_collector.append(matrix)
            labels = np.array([delta_x, delta_y])
            label_collector.append(labels)
            nfl_id_collector.append(nfl_id)
            flag_collector.append(is_eval_only_sample(game_id, play_id, nfl_id))

        except Exception as e:
            # raise e
            # filestr = 'error_' + str(game_id) + '_' + str(play_id) + '_' + str(frame) + '.txt'
            if verbose:
                print(f'{str(datetime.datetime.now())}   Caught error in matrix_fn. gameId: {game_id}, playId: {play_id}, frame: {frame}')
                print(str(e))
            
            # with open(filestr, 'w') as f:
            #     f.write(filestr + '\n')
            #    f.write(str(e))

    return matrix_collector, label_collector, nfl_id_collector, flag_collector

def generate_data(id_df, track=True):
    samples = 0
    counter = 0
    collector_X = []
    collector_y = []
    collector_id = []
    collector_flags = []

    matrix_fn = calculate_data_matrices_gunner

    for _, row in id_df.iterrows():
        # if track:
        counter += 1
        print(str(datetime.datetime.now()) + '   ' + str(counter) + '/' + str(id_df.shape[0]), end='\r')
        
        game_id = int(row['gameId'])
        play_id = int(row['playId'])
        
        start = 0
        end = 0

        if is_penalty_on_play(game_id, play_id):
            continue
            
        play = data_provider.get_play_by_id(game_id, play_id)
        try:
            start = (id_df.loc[(id_df['gameId'] == game_id) & (id_df['playId'] == play_id)])['ball_snap'].item()
            if play.special_teams_result == 'Downed':
                end = (id_df.loc[(id_df['gameId'] == game_id) & (id_df['playId'] == play_id)])['punt_land'].item()
                pass
            elif play.special_teams_result == 'Fair Catch':
                end = (id_df.loc[(id_df['gameId'] == game_id) & (id_df['playId'] == play_id)])['fair_catch'].item()
                pass
            elif play.special_teams_result == 'Return':
                # TODO: change
                end = (id_df.loc[(id_df['gameId'] == game_id) & (id_df['playId'] == play_id)])['punt_received'].item()
                pass
            elif play.special_teams_result == 'Muffed':
                # TODO: change
                end = (id_df.loc[(id_df['gameId'] == game_id) & (id_df['playId'] == play_id)])['punt_muffed'].item()
                if end == np.nan:
                    end = (id_df.loc[(id_df['gameId'] == game_id) & (id_df['playId'] == play_id)])['punt_land'].item()

            if (start is np.nan) or (end is np.nan) or (start < 0) or (end < 0) or (start > end):
                raise Exception()
        except:
            if track:
                print(f'{str(datetime.datetime.now())}   Caught start/end error in game {str(game_id)} on play {str(play_id)}.')
                print(f'{str(datetime.datetime.now())}   start: {str(start)}   :   end: {str(end)}')

        try:
            numbers = get_jersey_numbers_gunners(game_id, play_id)
        except:
            if track:
                print(f'{str(datetime.datetime.now())}   Caught gunner error in game {str(game_id)} on play {str(play_id)}.')

        try:
            frames = [int(start), int(end)]
            worked = True
        except:
            worked = False
            frames = [0, 0]
            if track:
                print(f'{str(datetime.datetime.now())}   Caught casting error {str(game_id)} on play {str(play_id)}.')
                print(f'{str(datetime.datetime.now())}   start:   {str(start)} | end: {str(end)}.')

        if worked:
            # generate data for every gunner available
            for number in numbers:
                npzs, labels, nfl_ids, eval_only_flags = matrix_fn(game_id, play_id, number, frames=frames, verbose=True)
                print(np.array(npzs).shape)
                if len(np.array(npzs).shape) == 4:
                    samples += np.array(npzs).shape[0]
                    print(f'{str(datetime.datetime.now())}   Samples: {samples}', end='\r')

                    collector_X.append(np.array(npzs))
                    collector_y.append(np.array(labels))
                    collector_id.append(nfl_ids)
                    collector_flags.append(eval_only_flags)

                    # filestr = prefix + str(game_id) + '_' + str(play_id) + '_gnr_' + str(number) + '_norm.npz'
                    # np.savez(filestr, np.array(npzs), np.array(labels))

    l = 32
    np_X = np.vstack(collector_X)
    np_y = np.vstack(collector_y)
    np_ids = np.hstack(collector_id)
    np_flags = np.hstack(collector_flags)
    
    while l < np_X.shape[0]:
        l += 32
    l -= 32
    
    np_X = np_X[:l, :, :, :]
    np_y = np_y[:l, :]
    np_ids = np_ids[:l]
    np_flags = np_flags[:l]
    
    return np_X, np_y, np_ids, np_flags


total_samples = 0

for section in range(1, 5):
    
    df = pd.read_csv(DATA_PATH + f'sections/section_{section}.csv')
    idf = df

    X, y, ids, flags = generate_data(id_df=idf, track=True)
    filestr = DATA_PATH + f'npy/section{section}'

    if not os.path.exists(f'{DATA_PATH}npy'):
        os.mkdir(f'{DATA_PATH}npy')

    total_samples += X.shape[0]
    
    print(f'\nSamples created: {total_samples}\n')

    with open(filestr + '_XFt.npy', 'wb') as f:   
        np.save(f, X)
    with open(filestr + '_yFt.npy', 'wb') as f:   
        np.save(f, y)
    with open(filestr + '_idsFt.npy', 'wb') as f:
        np.save(f, ids)
    with open(filestr + '_flagsFt.npy', 'wb') as f:
        np.save(f, flags)