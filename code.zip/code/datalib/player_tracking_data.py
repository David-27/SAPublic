class PlayerTrackingData:
    # contains all data of a player in one game during one play
    # at a given moment as represented by ~/data/tracking2018.csv
    
    def __init__(self, frame_id, game_id, play_id, nfl_id):
        self.frame_id = frame_id
        self.game_id = game_id
        self.play_id = play_id
        self.nfl_id = nfl_id
    
    def init_data(self, pandas_series):
        self.time = pandas_series['time']
        self.x = pandas_series['x']
        self.y = pandas_series['y']
        self.s = pandas_series['s']
        self.a = pandas_series['a']
        self.dis = pandas_series['dis']
        self.o = pandas_series['o']
        self.dir = pandas_series['dir']
        self.event = pandas_series['event']
        self.display_name = pandas_series['displayName']
        self.jersey_number = pandas_series['jerseyNumber']
        self.position = pandas_series['position']
        self.team = pandas_series['team']
        self.play_direction = pandas_series['playDirection']
    
    # def __init__(self, time, x, y, s, a, dis, o, dir, event, nfl_id, display_name, jersey_number, position, team, frame_id, game_id, play_id, play_direction):
    #     self.time = time
    #     self.x = x
    #     self.y = y
    #     self.s = s
    #     self.a = a
    #     self.dis = dis
    #     self.o = o
    #     self.dir = dir
    #     self.event = event
    #     self.nfl_id = nfl_id
    #     self.display_name = display_name
    #     self.jersey_number = jersey_number
    #     self.position = position
    #     self.team = team
    #     self.frame_id = frame_id
    #     self.game_id = game_id
    #     self.play_id = play_id
    #     self.play_direction = play_direction