from game.game import Game

if __name__ == "__main__":
       game = Game(2018123000, 36)
       game.run()