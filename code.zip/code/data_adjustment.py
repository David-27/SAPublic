import os
os.environ['PYGAME_HIDE_SUPPORT_PROMPT'] = "hide"

from football.fb_constants import FIELD_WIDTH, FIELD_LENGTH, YARD
import numpy as np
import pandas as pd

DATA_PATH = 'C:/Users/user/Studienarbeit/data/'

def transform_data(df):
    df = df.copy(deep = True)
    
    # if play direction is left transform play to play in the right direction
    c_x = (FIELD_LENGTH / YARD) / 2
    c_y = (FIELD_WIDTH / YARD) / 2
    
    def translate_x(x):
        return x + (2 * (c_x - x))
    
    def translate_y(y):
        return y + (2 * (c_y - y))
    
    def translate_angle(angle):
        if angle == np.nan:
            return angle
        while angle >= 360:
            angle -= 360
        while angle < 0:
            angle += 360
        return angle
    
    for i in range(0, df.shape[0]):
        if i % 100 == 0:
            print(f'{i}/{df.shape[0]}            ',end='\r')
        curr_index = df.index[i]
        play_dir = df.loc[curr_index, 'playDirection'] 
        if play_dir == 'left':
            df.loc[curr_index, 'playDirection'] = 'right_adj'
            
            # translate x and y values
            df.loc[curr_index, 'x'] = translate_x(df.loc[curr_index, 'x'])
            df.loc[curr_index, 'y'] = translate_y(df.loc[curr_index, 'y'])
            
            # tarnslate o and dir values
            df.loc[curr_index, 'o'] = translate_angle(df.loc[curr_index, 'o'] + 180)
            df.loc[curr_index, 'dir'] = translate_angle(df.loc[curr_index, 'dir'] + 180)
            
    return df

print('Adjusting tracking data...')
print('Loading tracking data...')
data_tracking = pd.read_csv(f'{DATA_PATH}punts_tracking.csv')
print('Loaded tracking data.')
print('Transforming tracking data...')
adjusted_tracking_data = transform_data(data_tracking)
print('Saving adjusted tracking data...')
adjusted_tracking_data.to_csv(f'{DATA_PATH}punts_tracking_adjusted.csv')
print('Saved adjusted tracking data.')